/*
 * Controller para gerenciamento de Anotações
 */
package controller;

import java.util.List;
import model.Anotacao;

/**
 *
 * @author jpescola
 */
public class AnotacaoController extends Controller<Anotacao> {

    @Override
    public boolean salvar(Anotacao t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Anotacao t) {
        return super.excluir(t);
    }

    public List<Anotacao> buscar(String campo, String valor) {
        return super.listar(Anotacao.class, campo, valor);
    }

    public Anotacao get(int id) {
        return super.get(Anotacao.class, id);
    }

    public List<Anotacao> listar() {
        return super.listar(Anotacao.class, "titulo", "");
    }

    public List<Anotacao> buscarPorCategoria(String categoria) {
        return super.listar(Anotacao.class, "categoria", categoria);
    }

    public List<Anotacao> buscarImportantes() {
        return super.listar(Anotacao.class, "importante", "true");
    }
}