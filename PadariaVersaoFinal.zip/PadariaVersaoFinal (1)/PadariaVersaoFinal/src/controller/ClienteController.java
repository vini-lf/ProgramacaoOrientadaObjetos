/*
 * Controller para gerenciamento de Clientes
 */
package controller;

import java.util.List;
import model.Cliente;

/**
 *
 * @author jpescola
 */
public class ClienteController extends Controller<Cliente> {

    @Override
    public boolean salvar(Cliente t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Cliente t) {
        return super.excluir(t);
    }

    public List<Cliente> buscar(String campo, String valor) {
        return super.listar(Cliente.class, campo, valor);
    }

    public Cliente get(int id) {
        return super.get(Cliente.class, id);
    }

    public List<Cliente> listar() {
        return super.listarTodos(Cliente.class);
    }

    public List<Cliente> buscarPorNome(String nome) {
        return super.listar(Cliente.class, "nome", nome);
    }

    public List<Cliente> buscarPorCpf(String cpf) {
        return super.listar(Cliente.class, "cpf", cpf);
    }
}