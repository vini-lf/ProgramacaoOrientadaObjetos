/*
 * Controller para Dashboard - Métricas da Padaria
 */
package controller;

import dao.Dao;
import model.*;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author jpescola
 */
public class DashboardController {
    
    private Dao dao;
    private EntityManagerFactory factory;
    private EntityManager manager;
    
    public DashboardController() {
        this.dao = Dao.getIntance();
        this.factory = Persistence.createEntityManagerFactory("ExemploPU");
        this.manager = factory.createEntityManager();
    }
    
    public int getQuantidadeEncomendasAbertas() {
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            String jpql = "SELECT COUNT(e) FROM Encomenda e WHERE e.status IN ('PENDENTE', 'PRONTA')";
            Long count = manager.createQuery(jpql, Long.class).getSingleResult();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
            return count.intValue();
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
            return 0;
        }
    }
    
    public int getQuantidadeClientes() {
        try {
            List<Cliente> clientes = dao.listarTodos(Cliente.class);
            return clientes != null ? clientes.size() : 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public int getQuantidadeItensEstoqueBaixo() {
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            String jpql = "SELECT COUNT(e) FROM Estoque e WHERE e.quantidade <= e.quantidadeMinima";
            Long count = manager.createQuery(jpql, Long.class).getSingleResult();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
            return count.intValue();
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
            return 0;
        }
    }
    
    public int getQuantidadeProdutos() {
        try {
            List<Produto> produtos = dao.listarTodos(Produto.class);
            return produtos != null ? produtos.size() : 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public double getTotalVendasPeriodo(int dias) {
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, -dias);
            Date dataInicio = cal.getTime();
            
            String jpql = "SELECT COALESCE(SUM(v.valorTotal), 0) FROM Venda v WHERE v.dataVenda >= :dataInicio";
            Double total = manager.createQuery(jpql, Double.class)
                    .setParameter("dataInicio", dataInicio)
                    .getSingleResult();
            
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
            return total != null ? total : 0.0;
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
            return 0.0;
        }
    }
    
    public void fechar() {
        if (manager != null && manager.isOpen()) {
            manager.close();
        }
        if (factory != null && factory.isOpen()) {
            factory.close();
        }
    }
}