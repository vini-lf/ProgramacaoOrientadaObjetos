/*
 * Controller para gerenciamento de Encomendas
 */
package controller;

import java.util.List;
import model.Encomenda;
import model.Cliente;

/**
 *
 * @author jpescola
 */
public class EncomendaController extends Controller<Encomenda> {

    @Override
    public boolean salvar(Encomenda encomenda) {
        try {
            System.out.println("Salvando encomenda - Cliente: " + encomenda.getCliente().getNome() + 
                             ", Valor: " + encomenda.getValorTotal() + 
                             ", Status: " + encomenda.getStatus());
            
            boolean sucesso = super.salvar(encomenda);
            
            if (sucesso) {
                System.out.println("Encomenda salva com sucesso - ID: " + encomenda.getId());
            } else {
                System.out.println("Erro ao salvar encomenda");
            }
            
            return sucesso;
        } catch (Exception e) {
            System.out.println("Exceção ao salvar encomenda: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean salvarEncomendaCompleta(Encomenda encomenda) {
        try {
            System.out.println("Salvando encomenda completa com " + 
                             (encomenda.getItens() != null ? encomenda.getItens().size() : 0) + " itens");
            
            // Salvar a encomenda com todos os itens usando cascade
            boolean sucesso = super.salvar(encomenda);
            
            if (sucesso) {
                System.out.println("Encomenda salva com ID: " + encomenda.getId());
            } else {
                System.out.println("Erro ao salvar encomenda completa");
            }
            
            return sucesso;
        } catch (Exception e) {
            System.out.println("Erro ao salvar encomenda completa: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean excluir(Encomenda t) {
        return super.excluir(t);
    }

    public List<Encomenda> buscar(String campo, String valor) {
        return super.listar(Encomenda.class, campo, valor);
    }

    public Encomenda get(int id) {
        return super.get(Encomenda.class, id);
    }

    public List<Encomenda> listar() {
        List<Encomenda> encomendas = super.listarTodos(Encomenda.class);
        return encomendas != null ? encomendas : new java.util.ArrayList<>();
    }

    public List<Encomenda> buscarPorCliente(int clienteId) {
        try {
            System.out.println("Buscando encomendas para cliente ID: " + clienteId);
            List<Encomenda> todasEncomendas = super.listarTodos(Encomenda.class);
            if (todasEncomendas == null) {
                System.out.println("Nenhuma encomenda encontrada no banco");
                return new java.util.ArrayList<>();
            }
            
            System.out.println("Total de encomendas no banco: " + todasEncomendas.size());
            List<Encomenda> encomendasCliente = todasEncomendas.stream()
                    .filter(e -> e.getCliente() != null && e.getCliente().getId() == clienteId)
                    .collect(java.util.stream.Collectors.toList());
            
            System.out.println("Encomendas do cliente " + clienteId + ": " + encomendasCliente.size());
            return encomendasCliente;
        } catch (Exception e) {
            System.out.println("Erro ao buscar encomendas por cliente: " + e.getMessage());
            e.printStackTrace();
            return new java.util.ArrayList<>();
        }
    }

    public List<Encomenda> buscarPorStatus(Encomenda.StatusEncomenda status) {
        try {
            List<Encomenda> todasEncomendas = super.listarTodos(Encomenda.class);
            if (todasEncomendas == null) {
                return new java.util.ArrayList<>();
            }
            return todasEncomendas.stream()
                    .filter(e -> e.getStatus() == status)
                    .collect(java.util.stream.Collectors.toList());
        } catch (Exception e) {
            System.out.println("Erro ao buscar por status: " + e.getMessage());
            return new java.util.ArrayList<>();
        }
    }

    public boolean cancelarEncomenda(Encomenda encomenda) {
        try {
            encomenda.setStatus(Encomenda.StatusEncomenda.CANCELADA);
            return salvar(encomenda);
        } catch (Exception e) {
            System.out.println("Erro ao cancelar encomenda: " + e.getMessage());
            return false;
        }
    }

    public boolean marcarComoPronta(Encomenda encomenda) {
        try {
            encomenda.setStatus(Encomenda.StatusEncomenda.PRONTA);
            return salvar(encomenda);
        } catch (Exception e) {
            System.out.println("Erro ao marcar encomenda como pronta: " + e.getMessage());
            return false;
        }
    }

    public boolean marcarComoEntregue(Encomenda encomenda) {
        try {
            encomenda.setStatus(Encomenda.StatusEncomenda.ENTREGUE);
            return salvar(encomenda);
        } catch (Exception e) {
            System.out.println("Erro ao marcar encomenda como entregue: " + e.getMessage());
            return false;
        }
    }
}