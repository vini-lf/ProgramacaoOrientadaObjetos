/*
 * Controller para gerenciamento de Estoque
 */
package controller;

import java.util.List;
import model.Estoque;
import model.Produto;

/**
 *
 * @author jpescola
 */
public class EstoqueController extends Controller<Estoque> {

    @Override
    public boolean salvar(Estoque t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Estoque t) {
        return super.excluir(t);
    }

    public List<Estoque> buscar(String campo, String valor) {
        return super.listar(Estoque.class, campo, valor);
    }

    public Estoque get(int id) {
        return super.get(Estoque.class, id);
    }

    public List<Estoque> listar() {
        List<Estoque> estoques = super.listarTodos(Estoque.class);
        return estoques != null ? estoques : new java.util.ArrayList<>();
    }

    public Estoque buscarPorProduto(Produto produto) {
        try {
            System.out.println("Buscando estoque para produto ID: " + produto.getId() + " - " + produto.getNome());
            
            // Usa o método específico para buscar estoque por produto
            List<Estoque> estoques = dao.Dao.getIntance().buscarEstoquePorProduto(produto.getId());
            System.out.println("Busca encontrou " + (estoques != null ? estoques.size() : 0) + " registros");
            
            if (estoques != null && !estoques.isEmpty()) {
                Estoque encontrado = estoques.get(0);
                System.out.println("Estoque encontrado - ID: " + encontrado.getId() + ", Quantidade: " + encontrado.getQuantidade());
                return encontrado;
            }
            
            System.out.println("Nenhum estoque encontrado para este produto");
            return null;
        } catch (Exception e) {
            System.out.println("Erro ao buscar estoque: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public List<Estoque> listarEstoqueBaixo() {
        // Busca produtos com estoque baixo (quantidade <= quantidadeMinima)
        List<Estoque> todosEstoques = super.listarTodos(Estoque.class);
        if (todosEstoques == null) {
            return new java.util.ArrayList<>();
        }
        return todosEstoques.stream()
                .filter(e -> e.isEstoqueBaixo())
                .collect(java.util.stream.Collectors.toList());
    }

    public boolean adicionarEstoque(Produto produto, int quantidade) {
        try {
            System.out.println("Tentando adicionar " + quantidade + " unidades ao produto: " + produto.getNome());
            Estoque estoque = buscarPorProduto(produto);
            
            if (estoque != null) {
                System.out.println("Estoque existente encontrado. Quantidade atual: " + estoque.getQuantidade());
                int novaQuantidade = estoque.getQuantidade() + quantidade;
                estoque.setQuantidade(novaQuantidade);
                System.out.println("Nova quantidade será: " + novaQuantidade);
                boolean resultado = salvar(estoque);
                System.out.println("Resultado da atualização: " + resultado);
                return resultado;
            } else {
                System.out.println("Criando novo registro de estoque");
                // Criar novo registro de estoque
                estoque = new Estoque();
                estoque.setProduto(produto);
                estoque.setQuantidade(quantidade);
                estoque.setQuantidadeMinima(5); // Valor padrão
                boolean resultado = salvar(estoque);
                System.out.println("Resultado da criação: " + resultado);
                return resultado;
            }
        } catch (Exception e) {
            System.out.println("Erro ao adicionar estoque: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean removerEstoque(Produto produto, int quantidade) {
        try {
            Estoque estoque = buscarPorProduto(produto);
            if (estoque == null) {
                System.out.println("Produto não encontrado no estoque: " + produto.getNome());
                return false;
            }
            
            if (estoque.getQuantidade() < quantidade) {
                System.out.println("Quantidade insuficiente. Disponível: " + estoque.getQuantidade() + ", Solicitado: " + quantidade);
                return false;
            }
            
            estoque.setQuantidade(estoque.getQuantidade() - quantidade);
            return salvar(estoque);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}