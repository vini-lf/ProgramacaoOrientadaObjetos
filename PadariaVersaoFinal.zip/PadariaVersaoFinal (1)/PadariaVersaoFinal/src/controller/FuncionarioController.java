/*
 * Controller para gerenciamento de Funcionários
 */
package controller;

import java.util.List;
import model.Funcionario;

/**
 *
 * @author jpescola
 */
public class FuncionarioController extends Controller<Funcionario> {

    @Override
    public boolean salvar(Funcionario t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Funcionario t) {
        return super.excluir(t);
    }

    public List<Funcionario> buscar(String campo, String valor) {
        return super.listar(Funcionario.class, campo, valor);
    }

    public Funcionario get(int id) {
        return super.get(Funcionario.class, id);
    }

    public List<Funcionario> listar() {
        return super.listarTodos(Funcionario.class);
    }

    public List<Funcionario> buscarPorNome(String nome) {
        return super.listar(Funcionario.class, "nome", nome);
    }

    public List<Funcionario> buscarPorEmail(String email) {
        return super.listar(Funcionario.class, "email", email);
    }
}