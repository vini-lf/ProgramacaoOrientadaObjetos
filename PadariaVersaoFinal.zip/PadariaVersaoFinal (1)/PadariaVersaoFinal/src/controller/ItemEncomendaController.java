/*
 * Controller para gerenciamento de Itens de Encomenda
 */
package controller;

import java.util.List;
import model.ItemEncomenda;

/**
 *
 * @author jpescola
 */
public class ItemEncomendaController extends Controller<ItemEncomenda> {

    @Override
    public boolean salvar(ItemEncomenda t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(ItemEncomenda t) {
        return super.excluir(t);
    }

    public List<ItemEncomenda> buscar(String campo, String valor) {
        return super.listar(ItemEncomenda.class, campo, valor);
    }

    public ItemEncomenda get(int id) {
        return super.get(ItemEncomenda.class, id);
    }

    public List<ItemEncomenda> listar() {
        return super.listarTodos(ItemEncomenda.class);
    }

    public List<ItemEncomenda> buscarPorEncomenda(int encomendaId) {
        try {
            List<ItemEncomenda> todosItens = super.listarTodos(ItemEncomenda.class);
            if (todosItens == null) {
                return new java.util.ArrayList<>();
            }
            return todosItens.stream()
                    .filter(item -> item.getEncomenda() != null && item.getEncomenda().getId() == encomendaId)
                    .collect(java.util.stream.Collectors.toList());
        } catch (Exception e) {
            System.out.println("Erro ao buscar itens por encomenda: " + e.getMessage());
            return new java.util.ArrayList<>();
        }
    }
}