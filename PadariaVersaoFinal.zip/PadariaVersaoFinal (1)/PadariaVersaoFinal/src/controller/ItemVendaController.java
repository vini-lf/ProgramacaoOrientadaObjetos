/*
 * Controller para gerenciamento de Itens de Venda
 */
package controller;

import java.util.List;
import model.ItemVenda;

/**
 *
 * @author jpescola
 */
public class ItemVendaController extends Controller<ItemVenda> {

    @Override
    public boolean salvar(ItemVenda t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(ItemVenda t) {
        return super.excluir(t);
    }

    public List<ItemVenda> buscar(String campo, String valor) {
        return super.listar(ItemVenda.class, campo, valor);
    }

    public ItemVenda get(int id) {
        return super.get(ItemVenda.class, id);
    }

    public List<ItemVenda> listar() {
        return super.listarTodos(ItemVenda.class);
    }

    public List<ItemVenda> buscarPorVenda(int vendaId) {
        try {
            List<ItemVenda> todosItens = super.listarTodos(ItemVenda.class);
            if (todosItens == null) {
                return new java.util.ArrayList<>();
            }
            return todosItens.stream()
                    .filter(item -> item.getVenda() != null && item.getVenda().getId() == vendaId)
                    .collect(java.util.stream.Collectors.toList());
        } catch (Exception e) {
            System.out.println("Erro ao buscar itens por venda: " + e.getMessage());
            return new java.util.ArrayList<>();
        }
    }
}