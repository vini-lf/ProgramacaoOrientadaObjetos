/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Receita;

/**
 *
 * @author jpescola
 */
public class ReceitaController extends Controller<Receita> {

    @Override
    public boolean salvar(Receita t) {
        return super.salvar(t);
    }

    @Override
    public boolean excluir(Receita t) {
        return super.excluir(t);
    }

    public List<Receita> buscar(String campo, String valor) {
        return super.listar(Receita.class, campo, valor);
    }

    public Receita get(int id) {
        return super.get(Receita.class, id);
    }

    public List<Receita> listar() {
        return super.listar(Receita.class, "nome", "");
    }
}