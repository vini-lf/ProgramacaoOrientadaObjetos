/*
 * Controller para gerenciamento de Vendas
 */
package controller;

import dao.Dao;
import java.util.List;
import model.Venda;
import model.Cliente;


/**
 *
 * @author jpescola
 */
public class VendaController extends Controller<Venda> {
    
    private Dao dao;

    
    public VendaController() {
        dao = Dao.getIntance();

    }

    @Override
    public boolean salvar(Venda venda) {
        try {
            System.out.println("Salvando venda - Cliente: " + venda.getCliente().getNome() + 
                             ", Valor: " + venda.getValorTotal() + 
                             ", Itens: " + (venda.getItens() != null ? venda.getItens().size() : 0));
            
            boolean sucesso = super.salvar(venda);
            
            if (sucesso) {
                System.out.println("Venda salva com sucesso - ID: " + venda.getId());
            } else {
                System.out.println("Erro ao salvar venda");
            }
            
            return sucesso;
        } catch (Exception e) {
            System.out.println("Exceção ao salvar venda: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean salvarVendaCompleta(Venda venda) {
        try {
            // Salvar apenas a venda primeiro, sem os itens
            Venda vendaTemp = new Venda();
            vendaTemp.setCliente(venda.getCliente());
            vendaTemp.setDataVenda(venda.getDataVenda());
            vendaTemp.setValorTotal(venda.getValorTotal());
            vendaTemp.setValorDesconto(venda.getValorDesconto());
            vendaTemp.setFormaPagamento(venda.getFormaPagamento());
            vendaTemp.setObservacoes(venda.getObservacoes());
            
            boolean sucesso = super.salvar(vendaTemp);
            if (sucesso) {
                venda.setId(vendaTemp.getId());
                System.out.println("Venda salva com ID único: " + venda.getId());
            }
            
            return sucesso;
        } catch (Exception e) {
            System.out.println("Erro ao salvar venda completa: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    


    @Override
    public boolean excluir(Venda t) {
        return super.excluir(t);
    }

    public List<Venda> buscar(String campo, String valor) {
        return super.listar(Venda.class, campo, valor);
    }

    public Venda get(int id) {
        return super.get(Venda.class, id);
    }

    public List<Venda> listar() {
        return super.listarTodos(Venda.class);
    }

    public List<Venda> buscarPorCliente(int clienteId) {
        // Implementação específica para buscar vendas por cliente
        return dao.buscarVendasPorCliente(clienteId);
    }
}