/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author jpescola
 */
public class Dao<T> {

    private EntityManagerFactory factory = null;
    private EntityManager manager = null;
    private static Dao instance = null;

    protected Dao() {
        factory = Persistence.createEntityManagerFactory("ExemploPU");
        manager = factory.createEntityManager();
    }

    public static Dao getIntance() {
        if (instance == null) {
            instance = new Dao();
        }
        return instance;
    }

    public void fechar() {
        manager.close();
        factory.close();
    }

    public boolean salvar(T t) {
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            
            // Verificar se é uma entidade nova (ID = 0) ou existente
            java.lang.reflect.Method getIdMethod = t.getClass().getMethod("getId");
            int id = (Integer) getIdMethod.invoke(t);
            
            if (id == 0) {
                // Entidade nova - usar persist para que o ID seja atualizado
                manager.persist(t);
            } else {
                // Entidade existente - usar merge
                t = manager.merge(t);
            }
            
            manager.flush();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean excluir(T t) {
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            T managedEntity = manager.merge(t);
            manager.remove(managedEntity);
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public List<T> listar(Class c, String campo, String valor) {
        List<T> lista = null;
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<T> criteria = builder.createQuery(c);
            Root<T> root = criteria.from(c);
            criteria.select(root);
            criteria.where(builder.like(root.get(campo), "%" + valor + "%"));
            lista = manager.createQuery(criteria).getResultList();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
        }
        return lista;
    }

    public T get(Class c, int id) {
        T t = null;
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            t = (T) manager.find(c, id);
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
        }
        return t;
    }

    public List<T> listarTodos(Class c) {
        List<T> lista = null;
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            CriteriaBuilder builder = manager.getCriteriaBuilder();
            CriteriaQuery<T> criteria = builder.createQuery(c);
            Root<T> root = criteria.from(c);
            criteria.select(root);
            lista = manager.createQuery(criteria).getResultList();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
        }
        return lista;
    }
    
    public List<T> buscarVendasPorCliente(int clienteId) {
        List<T> lista = null;
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            String jpql = "SELECT v FROM Venda v WHERE v.cliente.id = :clienteId ORDER BY v.dataVenda DESC";
            lista = manager.createQuery(jpql, (Class<T>) model.Venda.class)
                    .setParameter("clienteId", clienteId)
                    .getResultList();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
        }
        return lista;
    }
    
    public List<T> buscarEstoquePorProduto(int produtoId) {
        List<T> lista = null;
        try {
            if (!manager.getTransaction().isActive()) {
                manager.getTransaction().begin();
            }
            String jpql = "SELECT e FROM Estoque e WHERE e.produto.id = :produtoId";
            lista = manager.createQuery(jpql, (Class<T>) model.Estoque.class)
                    .setParameter("produtoId", produtoId)
                    .getResultList();
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().commit();
            }
        } catch (Exception e) {
            if (manager.getTransaction().isActive()) {
                manager.getTransaction().rollback();
            }
            e.printStackTrace();
        }
        return lista;
    }
}
