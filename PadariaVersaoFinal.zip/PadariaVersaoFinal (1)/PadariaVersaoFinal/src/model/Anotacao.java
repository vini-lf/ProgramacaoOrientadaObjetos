/*
 * Modelo para Anotações do sistema
 */
package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jpescola
 */
@Entity
public class Anotacao implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    private String titulo;
    private String conteudo;
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataHora;
    private String categoria;
    private boolean importante;

    public Anotacao() {
        this.dataHora = new Date();
        this.importante = false;
    }

    public Anotacao(int id, String titulo, String conteudo, String categoria, boolean importante) {
        this.id = id;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.categoria = categoria;
        this.importante = importante;
        this.dataHora = new Date();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Date getDataHora() {
        return dataHora;
    }

    public void setDataHora(Date dataHora) {
        this.dataHora = dataHora;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public boolean isImportante() {
        return importante;
    }

    public void setImportante(boolean importante) {
        this.importante = importante;
    }

    @Override
    public String toString() {
        return titulo;
    }
}