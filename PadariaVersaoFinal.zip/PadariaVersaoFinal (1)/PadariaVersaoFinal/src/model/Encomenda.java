/*
 * Modelo para Encomenda
 */
package model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jpescola
 */
@Entity
public class Encomenda implements Serializable {

    public enum StatusEncomenda {
        PENDENTE, PRONTA, ENTREGUE, CANCELADA
    }

    @Id
    @GeneratedValue
    private int id;
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataPedido;
    @Temporal(TemporalType.DATE)
    private Date dataRetirada;
    private float valorTotal;
    private String observacoes;
    @Enumerated(EnumType.STRING)
    private StatusEncomenda status;
    @ManyToOne
    private Cliente cliente;
    @OneToMany(mappedBy = "encomenda", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ItemEncomenda> itens;

    public Encomenda() {
        this.dataPedido = new Date();
        this.status = StatusEncomenda.PENDENTE;
    }

    public Encomenda(int id, Date dataPedido, Date dataRetirada, float valorTotal, 
                    String observacoes, StatusEncomenda status, Cliente cliente) {
        this.id = id;
        this.dataPedido = dataPedido;
        this.dataRetirada = dataRetirada;
        this.valorTotal = valorTotal;
        this.observacoes = observacoes;
        this.status = status;
        this.cliente = cliente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataPedido() {
        return dataPedido;
    }

    public void setDataPedido(Date dataPedido) {
        this.dataPedido = dataPedido;
    }

    public Date getDataRetirada() {
        return dataRetirada;
    }

    public void setDataRetirada(Date dataRetirada) {
        this.dataRetirada = dataRetirada;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public StatusEncomenda getStatus() {
        return status;
    }

    public void setStatus(StatusEncomenda status) {
        this.status = status;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<ItemEncomenda> getItens() {
        return itens;
    }

    public void setItens(List<ItemEncomenda> itens) {
        this.itens = itens;
    }

    @Override
    public String toString() {
        return "Encomenda #" + id + " - " + (cliente != null ? cliente.getNome() : "Cliente não definido");
    }
}