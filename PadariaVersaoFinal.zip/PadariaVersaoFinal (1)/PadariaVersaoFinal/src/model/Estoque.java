/*
 * Modelo para Estoque
 */
package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jpescola
 */
@Entity
public class Estoque implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    @ManyToOne
    private Produto produto;
    private int quantidade;
    private int quantidadeMinima;
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataUltimaAtualizacao;

    public Estoque() {
        this.dataUltimaAtualizacao = new Date();
    }

    public Estoque(int id, Produto produto, int quantidade, int quantidadeMinima) {
        this.id = id;
        this.produto = produto;
        this.quantidade = quantidade;
        this.quantidadeMinima = quantidadeMinima;
        this.dataUltimaAtualizacao = new Date();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
        this.dataUltimaAtualizacao = new Date();
    }

    public int getQuantidadeMinima() {
        return quantidadeMinima;
    }

    public void setQuantidadeMinima(int quantidadeMinima) {
        this.quantidadeMinima = quantidadeMinima;
    }

    public Date getDataUltimaAtualizacao() {
        return dataUltimaAtualizacao;
    }

    public void setDataUltimaAtualizacao(Date dataUltimaAtualizacao) {
        this.dataUltimaAtualizacao = dataUltimaAtualizacao;
    }

    public boolean isEstoqueBaixo() {
        return quantidade <= quantidadeMinima;
    }

    @Override
    public String toString() {
        return produto != null ? produto.getNome() + " (Qtd: " + quantidade + ")" : "Produto não definido";
    }
}