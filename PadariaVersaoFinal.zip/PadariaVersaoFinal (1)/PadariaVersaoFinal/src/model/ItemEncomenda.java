/*
 * Modelo para Item de Encomenda
 */
package model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author jpescola
 */
@Entity
public class ItemEncomenda implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    private int quantidade;
    private float precoUnitario;
    private float subtotal;
    @ManyToOne
    private Produto produto;
    @ManyToOne
    private Encomenda encomenda;

    public ItemEncomenda() {
    }

    public ItemEncomenda(int id, int quantidade, float precoUnitario, float subtotal, 
                        Produto produto, Encomenda encomenda) {
        this.id = id;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.subtotal = subtotal;
        this.produto = produto;
        this.encomenda = encomenda;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(float precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Encomenda getEncomenda() {
        return encomenda;
    }

    public void setEncomenda(Encomenda encomenda) {
        this.encomenda = encomenda;
    }

    public void calcularSubtotal() {
        this.subtotal = this.quantidade * this.precoUnitario;
    }

    @Override
    public String toString() {
        return produto != null ? produto.getNome() + " - Qtd: " + quantidade : "Produto não definido";
    }
}