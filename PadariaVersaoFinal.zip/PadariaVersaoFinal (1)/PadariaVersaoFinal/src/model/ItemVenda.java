/*
 * Modelo para Item de Venda
 */
package model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author jpescola
 */
@Entity
public class ItemVenda implements Serializable {

    @Id
    @GeneratedValue
    private int id;
    private int quantidade;
    private float precoUnitario;
    private float subtotal;
    @ManyToOne
    private Produto produto;
    @ManyToOne
    private Venda venda;

    public ItemVenda() {
    }

    public ItemVenda(int id, int quantidade, float precoUnitario, float subtotal, Produto produto, Venda venda) {
        this.id = id;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.subtotal = subtotal;
        this.produto = produto;
        this.venda = venda;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(float precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public void calcularSubtotal() {
        this.subtotal = this.quantidade * this.precoUnitario;
    }

    @Override
    public String toString() {
        return produto.getNome() + " - Qtd: " + quantidade;
    }
}