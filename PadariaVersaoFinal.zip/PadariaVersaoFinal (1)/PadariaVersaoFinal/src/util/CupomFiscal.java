/*
 * Classe para geração de cupom fiscal
 */
package util;

import model.Venda;
import model.ItemVenda;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.print.PrinterJob;
import java.awt.print.Printable;
import java.awt.print.PageFormat;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PrinterException;

/**
 *
 * @author jpescola
 */
public class CupomFiscal {
    
    private static final String NOME_EMPRESA = "PADARIA DO JOÃO";
    private static final String ENDERECO_EMPRESA = "Rua das Flores, 123 - Centro";
    private static final String TELEFONE_EMPRESA = "(11) 1234-5678";
    private static final String CNPJ_EMPRESA = "12.345.678/0001-90";
    
    public static void gerarCupom(Venda venda) {
        if (venda == null) {
            JOptionPane.showMessageDialog(null, "Venda não encontrada!");
            return;
        }
        
        String cupom = gerarTextoCupom(venda);
        
        // Mostrar cupom em uma janela
        JTextArea textArea = new JTextArea(cupom);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        textArea.setEditable(false);
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(400, 500));
        
        String[] opcoes = {"Imprimir", "Fechar"};
        int escolha = JOptionPane.showOptionDialog(
            null,
            scrollPane,
            "Cupom Fiscal - Venda #" + venda.getId(),
            JOptionPane.YES_NO_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            opcoes,
            opcoes[0]
        );
        
        if (escolha == 0) { // Imprimir
            imprimirCupom(cupom);
        }
    }
    
    private static String gerarTextoCupom(Venda venda) {
        StringBuilder cupom = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        
        // Cabeçalho
        cupom.append("=======================================\n");
        cupom.append("           ").append(NOME_EMPRESA).append("\n");
        cupom.append("       ").append(ENDERECO_EMPRESA).append("\n");
        cupom.append("         Tel: ").append(TELEFONE_EMPRESA).append("\n");
        cupom.append("         CNPJ: ").append(CNPJ_EMPRESA).append("\n");
        cupom.append("=======================================\n");
        cupom.append("              CUPOM FISCAL\n");
        cupom.append("=======================================\n\n");
        
        // Dados da venda
        cupom.append("Venda #: ").append(venda.getId()).append("\n");
        cupom.append("Data/Hora: ").append(dateFormat.format(venda.getDataVenda())).append("\n");
        cupom.append("Cliente: ").append(venda.getCliente().getNome()).append("\n");
        cupom.append("Forma Pagamento: ").append(venda.getFormaPagamento()).append("\n");
        
        if (venda.getObservacoes() != null && !venda.getObservacoes().trim().isEmpty()) {
            cupom.append("Observações: ").append(venda.getObservacoes()).append("\n");
        }
        
        cupom.append("\n=======================================\n");
        cupom.append("                ITENS\n");
        cupom.append("=======================================\n");
        
        // Cabeçalho dos itens
        cupom.append(String.format("%-20s %3s %8s %8s\n", "PRODUTO", "QTD", "UNIT.", "TOTAL"));
        cupom.append("---------------------------------------\n");
        
        // Itens da venda
        float totalGeral = 0.0f;
        if (venda.getItens() != null) {
            for (ItemVenda item : venda.getItens()) {
                String nomeProduto = item.getProduto().getNome();
                if (nomeProduto.length() > 20) {
                    nomeProduto = nomeProduto.substring(0, 17) + "...";
                }
                
                cupom.append(String.format("%-20s %3d %8.2f %8.2f\n",
                    nomeProduto,
                    item.getQuantidade(),
                    item.getPrecoUnitario(),
                    item.getSubtotal()
                ));
                
                totalGeral += item.getSubtotal();
            }
        }
        
        cupom.append("---------------------------------------\n");
        cupom.append(String.format("TOTAL GERAL: %21.2f\n", totalGeral));
        cupom.append("=======================================\n\n");
        
        // Rodapé
        cupom.append("        Obrigado pela preferência!\n");
        cupom.append("         Volte sempre!\n\n");
        cupom.append("Cupom gerado em: ").append(dateFormat.format(new Date())).append("\n");
        cupom.append("=======================================\n");
        
        return cupom.toString();
    }
    
    private static void imprimirCupom(String textoCupom) {
        try {
            PrinterJob job = PrinterJob.getPrinterJob();
            
            job.setPrintable(new Printable() {
                @Override
                public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
                    if (pageIndex > 0) {
                        return NO_SUCH_PAGE;
                    }
                    
                    Graphics2D g2d = (Graphics2D) graphics;
                    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                    
                    // Configurar fonte
                    Font font = new Font(Font.MONOSPACED, Font.PLAIN, 10);
                    g2d.setFont(font);
                    
                    // Imprimir linha por linha
                    String[] linhas = textoCupom.split("\n");
                    int y = 20;
                    int alturaLinha = 12;
                    
                    for (String linha : linhas) {
                        g2d.drawString(linha, 10, y);
                        y += alturaLinha;
                    }
                    
                    return PAGE_EXISTS;
                }
            });
            
            if (job.printDialog()) {
                job.print();
                JOptionPane.showMessageDialog(null, "Cupom enviado para impressão!");
            }
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null, 
                "Erro ao imprimir cupom: " + e.getMessage(),
                "Erro de Impressão",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void gerarCupomSimples(Venda venda) {
        if (venda == null) {
            JOptionPane.showMessageDialog(null, "Venda não encontrada!");
            return;
        }
        
        String cupom = gerarTextoCupom(venda);
        
        // Mostrar apenas o cupom sem opção de impressão
        JTextArea textArea = new JTextArea(cupom);
        textArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        textArea.setEditable(false);
        
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(400, 500));
        
        JOptionPane.showMessageDialog(
            null,
            scrollPane,
            "Cupom Fiscal - Venda #" + venda.getId(),
            JOptionPane.INFORMATION_MESSAGE
        );
    }
}