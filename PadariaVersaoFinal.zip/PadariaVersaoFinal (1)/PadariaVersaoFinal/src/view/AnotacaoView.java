/*
 * View para gerenciamento de Anotações
 */
package view;

import controller.AnotacaoController;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Anotacao;

/**
 *
 * @author jpescola
 */
public class AnotacaoView extends javax.swing.JFrame {

    private AnotacaoController controller;
    private List<Anotacao> anotacoes;
    private SimpleDateFormat dateFormat;

    /**
     * Creates new form AnotacaoView
     */
    public AnotacaoView() {
        initComponents();
        controller = new AnotacaoController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        loadCategorias();
        loadTabela();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(AnotacaoView.this);
            }
        });
    }

    private void loadCategorias() {
        cmbCategoria.removeAllItems();
        cmbCategoria.addItem("Geral");
        cmbCategoria.addItem("Produção");
        cmbCategoria.addItem("Vendas");
        cmbCategoria.addItem("Fornecedores");
        cmbCategoria.addItem("Funcionários");
        cmbCategoria.addItem("Financeiro");
        cmbCategoria.addItem("Receitas");
        cmbCategoria.addItem("Lembretes");
    }

    private void loadTabela() {
        anotacoes = controller.listar();
        DefaultTableModel model = (DefaultTableModel) tblAnotacoes.getModel();
        model.setRowCount(0);
        
        for (Anotacao a : anotacoes) {
            model.addRow(new Object[]{
                a.getId(),
                a.getTitulo(),
                a.getCategoria(),
                dateFormat.format(a.getDataHora()),
                a.isImportante() ? "Sim" : "Não"
            });
        }
    }

    private void limparCampos() {
        txtTitulo.setText("");
        txtConteudo.setText("");
        cmbCategoria.setSelectedIndex(0);
        chkImportante.setSelected(false);
        txtTitulo.requestFocus();
    }

    private void loadAnotacao() {
        int selectedRow = tblAnotacoes.getSelectedRow();
        if (selectedRow >= 0) {
            Anotacao a = anotacoes.get(selectedRow);
            txtTitulo.setText(a.getTitulo());
            txtConteudo.setText(a.getConteudo());
            cmbCategoria.setSelectedItem(a.getCategoria());
            chkImportante.setSelected(a.isImportante());
        }
    }

    private void salvar() {
        try {
            String titulo = txtTitulo.getText().trim();
            String conteudo = txtConteudo.getText().trim();
            String categoria = (String) cmbCategoria.getSelectedItem();
            boolean importante = chkImportante.isSelected();

            if (titulo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Título é obrigatório!");
                return;
            }

            if (conteudo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Conteúdo é obrigatório!");
                return;
            }

            Anotacao anotacao = new Anotacao();
            anotacao.setTitulo(titulo);
            anotacao.setConteudo(conteudo);
            anotacao.setCategoria(categoria);
            anotacao.setImportante(importante);

            // Se há uma linha selecionada, é uma edição
            int selectedRow = tblAnotacoes.getSelectedRow();
            if (selectedRow >= 0) {
                anotacao.setId(anotacoes.get(selectedRow).getId());
                anotacao.setDataHora(anotacoes.get(selectedRow).getDataHora());
            }

            if (controller.salvar(anotacao)) {
                JOptionPane.showMessageDialog(this, "Anotação salva com sucesso!");
                limparCampos();
                loadTabela();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar anotação!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
        }
    }

    private void excluir() {
        int selectedRow = tblAnotacoes.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Deseja realmente excluir esta anotação?", 
                "Confirmar exclusão", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                Anotacao anotacao = anotacoes.get(selectedRow);
                if (controller.excluir(anotacao)) {
                    JOptionPane.showMessageDialog(this, "Anotação excluída com sucesso!");
                    limparCampos();
                    loadTabela();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir anotação!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma anotação para excluir!");
        }
    }

    private void filtrarPorCategoria() {
        String categoria = (String) cmbFiltroCategoria.getSelectedItem();
        if ("Todas".equals(categoria)) {
            anotacoes = controller.listar();
        } else {
            anotacoes = controller.buscarPorCategoria(categoria);
        }
        
        DefaultTableModel model = (DefaultTableModel) tblAnotacoes.getModel();
        model.setRowCount(0);
        
        for (Anotacao a : anotacoes) {
            model.addRow(new Object[]{
                a.getId(),
                a.getTitulo(),
                a.getCategoria(),
                dateFormat.format(a.getDataHora()),
                a.isImportante() ? "Sim" : "Não"
            });
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTitulo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtConteudo = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox<>();
        chkImportante = new javax.swing.JCheckBox();
        btnSalvar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cmbFiltroCategoria = new javax.swing.JComboBox<>();
        btnFiltrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblAnotacoes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciar Anotações - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/Edit_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Nova Anotação"));

        jLabel1.setText("Título:");

        jLabel2.setText("Conteúdo:");

        txtConteudo.setColumns(20);
        txtConteudo.setRows(5);
        jScrollPane2.setViewportView(txtConteudo);

        jLabel3.setText("Categoria:");

        chkImportante.setText("Importante");

        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Save_16x16.png")));
        btnSalvar.setText("Salvar");
        btnSalvar.setBackground(new java.awt.Color(46, 204, 113));
        btnSalvar.setForeground(java.awt.Color.WHITE);
        btnSalvar.setFocusPainted(false);
        btnSalvar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Delete_16x16.png")));
        btnExcluir.setText("Excluir");
        btnExcluir.setBackground(new java.awt.Color(231, 76, 60));
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFocusPainted(false);
        btnExcluir.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTitulo))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chkImportante)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chkImportante))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnLimpar)
                    .addComponent(btnExcluir))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));

        jLabel4.setText("Categoria:");

        cmbFiltroCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas", "Geral", "Produção", "Vendas", "Fornecedores", "Funcionários", "Financeiro", "Receitas", "Lembretes" }));

        btnFiltrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Find_16x16.png")));
        btnFiltrar.setText("Filtrar");
        btnFiltrar.setBackground(new java.awt.Color(52, 152, 219));
        btnFiltrar.setForeground(java.awt.Color.WHITE);
        btnFiltrar.setFocusPainted(false);
        btnFiltrar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbFiltroCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFiltrar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbFiltroCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFiltrar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblAnotacoes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Título", "Categoria", "Data/Hora", "Importante"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblAnotacoes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblAnotacoesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblAnotacoes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        salvar();
    }                                         

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparCampos();
    }                                         

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {                                           
        excluir();
    }                                          

    private void tblAnotacoesMouseClicked(java.awt.event.MouseEvent evt) {                                          
        loadAnotacao();
    }                                         

    private void btnFiltrarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        filtrarPorCategoria();
    }                                          

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JCheckBox chkImportante;
    private javax.swing.JComboBox<String> cmbCategoria;
    private javax.swing.JComboBox<String> cmbFiltroCategoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblAnotacoes;
    private javax.swing.JTextArea txtConteudo;
    private javax.swing.JTextField txtTitulo;
    // End of variables declaration                   
}