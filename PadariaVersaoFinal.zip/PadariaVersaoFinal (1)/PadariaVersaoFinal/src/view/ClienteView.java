/*
 * View para gerenciamento de Clientes
 */
package view;

import controller.ClienteController;
import controller.VendaController;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cliente;
import model.Venda;

/**
 *
 * @author jpescola
 */
public class ClienteView extends javax.swing.JFrame {

    private ClienteController controller;
    private VendaController vendaController;
    private List<Cliente> clientes;
    private SimpleDateFormat dateFormat;

    /**
     * Creates new form ClienteView
     */
    public ClienteView() {
        initComponents();
        controller = new ClienteController();
        vendaController = new VendaController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        loadTabela();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(ClienteView.this);
            }
        });
    }

    private void loadTabela() {
        clientes = controller.listar();
        DefaultTableModel model = (DefaultTableModel) tblClientes.getModel();
        model.setRowCount(0);
        
        if (clientes != null && !clientes.isEmpty()) {
            for (Cliente c : clientes) {
                String dataNasc = c.getDataNascimento() != null ? dateFormat.format(c.getDataNascimento()) : "";
                model.addRow(new Object[]{
                    c.getId(),
                    c.getNome(),
                    c.getCpf(),
                    c.getTelefone(),
                    c.getEmail(),
                    dataNasc
                });
            }
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtCpf.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        txtEndereco.setText("");
        txtDataNascimento.setText("");
        
        // Limpa também o histórico
        DefaultTableModel model = (DefaultTableModel) tblHistorico.getModel();
        model.setRowCount(0);
        
        txtNome.requestFocus();
    }

    private void loadCliente() {
        int selectedRow = tblClientes.getSelectedRow();
        if (selectedRow >= 0 && clientes != null && selectedRow < clientes.size()) {
            Cliente c = clientes.get(selectedRow);
            System.out.println("Cliente selecionado: " + c.getNome() + " (ID: " + c.getId() + ")");
            
            txtNome.setText(c.getNome() != null ? c.getNome() : "");
            txtCpf.setText(c.getCpf() != null ? c.getCpf() : "");
            txtTelefone.setText(c.getTelefone() != null ? c.getTelefone() : "");
            txtEmail.setText(c.getEmail() != null ? c.getEmail() : "");
            txtEndereco.setText(c.getEndereco() != null ? c.getEndereco() : "");
            
            if (c.getDataNascimento() != null) {
                txtDataNascimento.setText(dateFormat.format(c.getDataNascimento()));
            } else {
                txtDataNascimento.setText("");
            }
            
            // Carrega o histórico de compras
            loadHistoricoCompras(c.getId());
            
            // Opcional: muda para a aba do histórico para mostrar os dados
            // jTabbedPane1.setSelectedIndex(1);
        }
    }

    private void loadHistoricoCompras(int clienteId) {
        try {
            System.out.println("Carregando histórico para cliente ID: " + clienteId);
            List<Venda> vendas = vendaController.buscarPorCliente(clienteId);
            DefaultTableModel model = (DefaultTableModel) tblHistorico.getModel();
            model.setRowCount(0);
            
            if (vendas != null && !vendas.isEmpty()) {
                System.out.println("Vendas encontradas: " + vendas.size());
                for (Venda v : vendas) {
                    String formaPagamento = v.getFormaPagamento() != null ? v.getFormaPagamento() : "N/A";
                    model.addRow(new Object[]{
                        v.getId(),
                        dateFormat.format(v.getDataVenda()),
                        String.format("R$ %.2f", v.getValorTotal()),
                        formaPagamento
                    });
                }
                // Força a atualização da tabela
                tblHistorico.revalidate();
                tblHistorico.repaint();
            } else {
                System.out.println("Nenhuma venda encontrada para o cliente ID: " + clienteId);
            }
        } catch (Exception e) {
            System.err.println("Erro ao carregar histórico: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao carregar histórico de compras: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void salvar() {
        try {
            String nome = txtNome.getText().trim();
            String cpf = txtCpf.getText().trim();
            String telefone = txtTelefone.getText().trim();
            String email = txtEmail.getText().trim();
            String endereco = txtEndereco.getText().trim();
            String dataNascStr = txtDataNascimento.getText().trim();

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome é obrigatório!");
                return;
            }

            Cliente cliente = new Cliente();
            cliente.setNome(nome);
            cliente.setCpf(cpf);
            cliente.setTelefone(telefone);
            cliente.setEmail(email);
            cliente.setEndereco(endereco);

            if (!dataNascStr.isEmpty()) {
                try {
                    Date dataNasc = dateFormat.parse(dataNascStr);
                    cliente.setDataNascimento(dataNasc);
                } catch (ParseException e) {
                    JOptionPane.showMessageDialog(this, "Data de nascimento inválida! Use o formato dd/MM/yyyy");
                    return;
                }
            }

            // Se há uma linha selecionada, é uma edição
            int selectedRow = tblClientes.getSelectedRow();
            if (selectedRow >= 0) {
                cliente.setId(clientes.get(selectedRow).getId());
                cliente.setDataCadastro(clientes.get(selectedRow).getDataCadastro());
            }

            if (controller.salvar(cliente)) {
                JOptionPane.showMessageDialog(this, "Cliente salvo com sucesso!");
                limparCampos();
                loadTabela();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar cliente!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
        }
    }

    private void excluir() {
        int selectedRow = tblClientes.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Deseja realmente excluir este cliente?", 
                "Confirmar exclusão", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                Cliente cliente = clientes.get(selectedRow);
                if (controller.excluir(cliente)) {
                    JOptionPane.showMessageDialog(this, "Cliente excluído com sucesso!");
                    limparCampos();
                    loadTabela();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir cliente!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um cliente para excluir!");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDataNascimento = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblHistorico = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciar Clientes - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/User_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Cliente"));

        jLabel1.setText("Nome:");

        jLabel2.setText("CPF:");

        jLabel3.setText("Telefone:");

        jLabel4.setText("Email:");

        jLabel5.setText("Endereço:");

        jLabel6.setText("Data Nascimento:");

        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Save_16x16.png")));
        btnSalvar.setText("Salvar");
        btnSalvar.setBackground(new java.awt.Color(46, 204, 113));
        btnSalvar.setForeground(java.awt.Color.WHITE);
        btnSalvar.setFocusPainted(false);
        btnSalvar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Delete_16x16.png")));
        btnExcluir.setText("Excluir");
        btnExcluir.setBackground(new java.awt.Color(231, 76, 60));
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFocusPainted(false);
        btnExcluir.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNome))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefone)
                            .addComponent(txtCpf)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmail))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEndereco))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnLimpar)
                    .addComponent(btnExcluir))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "CPF", "Telefone", "Email", "Data Nascimento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblClientes);

        jTabbedPane1.addTab("Clientes", jScrollPane1);

        tblHistorico.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Venda", "Data", "Valor Total", "Forma Pagamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblHistorico);

        jTabbedPane1.addTab("Histórico de Compras", jScrollPane2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        salvar();
    }                                         

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparCampos();
    }                                         

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {                                           
        excluir();
    }                                          

    private void tblClientesMouseClicked(java.awt.event.MouseEvent evt) {                                         
        loadCliente();
    }                                        

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTable tblHistorico;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtDataNascimento;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration                   
}