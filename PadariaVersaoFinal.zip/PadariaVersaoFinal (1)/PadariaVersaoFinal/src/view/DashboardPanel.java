/*
 * Painel de Dashboard com métricas da Padaria
 */
package view;

import controller.DashboardController;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author jpescola
 */
public class DashboardPanel extends JPanel {
    
    private DashboardController controller;
    private JLabel lblEncomendasAbertas;
    private JLabel lblQuantidadeClientes;
    private JLabel lblEstoqueBaixo;
    private JLabel lblQuantidadeProdutos;
    private JLabel lblTotalVendas;
    private JComboBox<String> cbPeriodoVendas;
    private Timer timer;
    
    public DashboardPanel() {
        this.controller = new DashboardController();
        configurarFonteEmojis();
        initComponents();
        atualizarDados();
        iniciarAtualizacaoAutomatica();
    }
    
    private void configurarFonteEmojis() {
        // Configurar encoding UTF-8
        System.setProperty("file.encoding", "UTF-8");
        System.setProperty("sun.jnu.encoding", "UTF-8");
        
        // Tentar registrar fontes que suportam emojis no Windows
        try {
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            
            // Fontes que geralmente suportam emojis no Windows
            String[] fontesEmoji = {
                "Segoe UI Emoji",
                "Segoe UI Symbol", 
                "Noto Color Emoji",
                "Apple Color Emoji",
                "Twemoji Mozilla"
            };
            
            // Verificar se alguma fonte de emoji está disponível
            String[] fontesDisponiveis = ge.getAvailableFontFamilyNames();
            for (String fonteEmoji : fontesEmoji) {
                for (String fonteDisponivel : fontesDisponiveis) {
                    if (fonteDisponivel.contains(fonteEmoji)) {
                        UIManager.put("Label.font", new Font(fonteEmoji, Font.PLAIN, 12));
                        UIManager.put("Button.font", new Font(fonteEmoji, Font.PLAIN, 12));
                        return;
                    }
                }
            }
            
            // Fallback: usar fonte padrão com melhor suporte Unicode
            UIManager.put("Label.font", new Font("Dialog", Font.PLAIN, 12));
            UIManager.put("Button.font", new Font("Dialog", Font.PLAIN, 12));
            
        } catch (Exception e) {
            System.err.println("Erro ao configurar fonte para emojis: " + e.getMessage());
        }
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        
        // Título principal
        JPanel painelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        painelTitulo.setBackground(new Color(245, 245, 245));
        JLabel lblTitulo = new JLabel("Sistema de Gestão da Padaria Vinicius e Estefani - Dashboard");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(139, 69, 19));
        painelTitulo.add(lblTitulo);
        add(painelTitulo, BorderLayout.NORTH);
        
        // Painel central com métricas e ações
        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));
        painelCentral.setBackground(new Color(245, 245, 245));
        painelCentral.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Painel de métricas (parte superior)
        JPanel painelMetricas = new JPanel(new GridLayout(2, 3, 15, 15));
        painelMetricas.setBackground(new Color(245, 245, 245));
        
        // Card Encomendas Abertas
        JPanel cardEncomendas = criarCard("Encomendas Abertas", "0", new Color(255, 152, 0));
        lblEncomendasAbertas = (JLabel) ((JPanel) cardEncomendas.getComponent(1)).getComponent(0);
        painelMetricas.add(cardEncomendas);
        
        // Card Clientes
        JPanel cardClientes = criarCard("Total de Clientes", "0", new Color(52, 152, 219));
        lblQuantidadeClientes = (JLabel) ((JPanel) cardClientes.getComponent(1)).getComponent(0);
        painelMetricas.add(cardClientes);
        
        // Card Estoque Baixo
        JPanel cardEstoque = criarCard("⚠ Itens Estoque Baixo", "0", new Color(231, 76, 60));
        lblEstoqueBaixo = (JLabel) ((JPanel) cardEstoque.getComponent(1)).getComponent(0);
        painelMetricas.add(cardEstoque);
        
        // Card Produtos
        JPanel cardProdutos = criarCard("Total de Produtos", "0", new Color(46, 204, 113));
        lblQuantidadeProdutos = (JLabel) ((JPanel) cardProdutos.getComponent(1)).getComponent(0);
        painelMetricas.add(cardProdutos);
        
        // Card Vendas com ComboBox para período
        JPanel cardVendas = criarCardVendas();
        painelMetricas.add(cardVendas);
        
        // Card de Atualização
        JPanel cardAtualizacao = criarCardAtualizacao();
        painelMetricas.add(cardAtualizacao);
        
        painelCentral.add(painelMetricas, BorderLayout.CENTER);
        
        // Painel de ações rápidas (parte inferior)
        JPanel painelAcoes = criarPainelAcoesRapidas();
        painelCentral.add(painelAcoes, BorderLayout.SOUTH);
        
        add(painelCentral, BorderLayout.CENTER);
    }
    
    private JPanel criarCard(String titulo, String valor, Color cor) {
        // Painel principal com bordas arredondadas
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Sombra
                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 15, 15);
                
                // Fundo do card
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 15, 15);
                
                g2.dispose();
            }
        };
        
        card.setOpaque(false);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Título
        JLabel lblTitulo = new JLabel(titulo, SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setForeground(new Color(60, 60, 60));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));
        
        // Valor
        JPanel painelValor = new JPanel(new FlowLayout(FlowLayout.CENTER));
        painelValor.setOpaque(false);
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Arial", Font.BOLD, 32));
        lblValor.setForeground(cor);
        painelValor.add(lblValor);
        
        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(painelValor, BorderLayout.CENTER);
        
        // Adicionar efeito hover melhorado
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                card.setBackground(new Color(248, 250, 252));
                card.repaint();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                card.setBackground(Color.WHITE);
                card.repaint();
            }
        });
        
        return card;
    }
    
    private JPanel criarCardVendas() {
        // Painel principal com bordas arredondadas
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Sombra
                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 15, 15);
                
                // Fundo do card
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 15, 15);
                
                g2.dispose();
            }
        };
        
        card.setOpaque(false);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Título com ComboBox
        JPanel painelTitulo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        painelTitulo.setOpaque(false);
        JLabel lblTitulo = new JLabel("$ Vendas ");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setForeground(new Color(60, 60, 60));
        
        cbPeriodoVendas = new JComboBox<>(new String[]{"Selecione período", "7 dias", "30 dias", "90 dias"});
        cbPeriodoVendas.setSelectedIndex(0);
        cbPeriodoVendas.setBackground(Color.WHITE);
        cbPeriodoVendas.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        cbPeriodoVendas.addActionListener(e -> atualizarVendas());
        
        painelTitulo.add(lblTitulo);
        painelTitulo.add(cbPeriodoVendas);
        
        // Valor
        JPanel painelValor = new JPanel(new FlowLayout(FlowLayout.CENTER));
        painelValor.setOpaque(false);
        lblTotalVendas = new JLabel("Selecione período");
        lblTotalVendas.setFont(new Font("Arial", Font.BOLD, 26));
        lblTotalVendas.setForeground(new Color(39, 174, 96));
        painelValor.add(lblTotalVendas);
        
        card.add(painelTitulo, BorderLayout.NORTH);
        card.add(painelValor, BorderLayout.CENTER);
        
        // Adicionar efeito hover melhorado
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                card.setBackground(new Color(248, 250, 252));
                card.repaint();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                card.setBackground(Color.WHITE);
                card.repaint();
            }
        });
        
        return card;
    }
    
    private JPanel criarCardAtualizacao() {
        // Painel principal com bordas arredondadas
        JPanel card = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Sombra
                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 15, 15);
                
                // Fundo do card
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 15, 15);
                
                g2.dispose();
            }
        };
        
        card.setOpaque(false);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel lblTitulo = new JLabel("↻ Atualização", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setForeground(new Color(60, 60, 60));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(5, 5, 10, 5));
        
        JPanel painelBotao = new JPanel(new FlowLayout(FlowLayout.CENTER));
        painelBotao.setOpaque(false);
        
        // Botão com bordas arredondadas
        JButton btnAtualizar = new JButton("Atualizar Dados") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        
        btnAtualizar.setFont(new Font("Arial", Font.BOLD, 12));
        btnAtualizar.setBackground(new Color(52, 152, 219));
        btnAtualizar.setForeground(Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnAtualizar.setOpaque(false);
        btnAtualizar.setContentAreaFilled(false);
        btnAtualizar.addActionListener(e -> atualizarDados());
        
        // Efeito hover no botão melhorado
        btnAtualizar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAtualizar.setBackground(new Color(41, 128, 185));
                btnAtualizar.repaint();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAtualizar.setBackground(new Color(52, 152, 219));
                btnAtualizar.repaint();
            }
        });
        
        painelBotao.add(btnAtualizar);
        
        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(painelBotao, BorderLayout.CENTER);
        
        // Adicionar efeito hover no card melhorado
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                card.setBackground(new Color(248, 250, 252));
                card.repaint();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                card.setBackground(Color.WHITE);
                card.repaint();
            }
        });
        
        return card;
    }
    
    private void atualizarDados() {
        SwingUtilities.invokeLater(() -> {
            try {
                lblEncomendasAbertas.setText(String.valueOf(controller.getQuantidadeEncomendasAbertas()));
                lblQuantidadeClientes.setText(String.valueOf(controller.getQuantidadeClientes()));
                lblEstoqueBaixo.setText(String.valueOf(controller.getQuantidadeItensEstoqueBaixo()));
                lblQuantidadeProdutos.setText(String.valueOf(controller.getQuantidadeProdutos()));
                atualizarVendas();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erro ao atualizar dados: " + e.getMessage(), 
                                            "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
    
    private void atualizarVendas() {
        try {
            String periodo = (String) cbPeriodoVendas.getSelectedItem();
            
            if (periodo == null || periodo.equals("Selecione período")) {
                lblTotalVendas.setText("Selecione um período");
                return;
            }
            
            int dias = 7; // padrão
            
            if (periodo.contains("30")) {
                dias = 30;
            } else if (periodo.contains("90")) {
                dias = 90;
            }
            
            double total = controller.getTotalVendasPeriodo(dias);
            NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
            lblTotalVendas.setText(formatter.format(total));
        } catch (Exception e) {
            e.printStackTrace();
            lblTotalVendas.setText("R$ 0,00");
        }
    }
    
    private void iniciarAtualizacaoAutomatica() {
        // Atualiza os dados a cada 5 minutos
        timer = new Timer(300000, e -> atualizarDados());
        timer.start();
    }
    
    private JPanel criarPainelAcoesRapidas() {
        JPanel painelAcoes = new JPanel(new BorderLayout());
        painelAcoes.setBackground(new Color(245, 245, 245));
        painelAcoes.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        // Título do painel de ações
        JLabel lblTituloAcoes = new JLabel("⚡ Ações Rápidas", SwingConstants.CENTER);
        lblTituloAcoes.setFont(new Font("Arial", Font.BOLD, 18));
        lblTituloAcoes.setForeground(new Color(139, 69, 19));
        lblTituloAcoes.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painelAcoes.add(lblTituloAcoes, BorderLayout.NORTH);
        
        // Painel com botões de ação
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        painelBotoes.setBackground(new Color(245, 245, 245));
        
        // Botão Nova Venda (destaque principal)
        JButton btnNovaVenda = criarBotaoAcao("+ Nova Venda", 
            "Criar uma nova venda rapidamente", 
            new Color(46, 204, 113), 
            e -> abrirNovaVenda());
        painelBotoes.add(btnNovaVenda);
        
        // Botão Gerenciar Vendas
        JButton btnGerenciarVendas = criarBotaoAcao("≡ Gerenciar Vendas", 
            "Ver histórico e gerenciar vendas", 
            new Color(52, 152, 219), 
            e -> abrirGerenciarVendas());
        painelBotoes.add(btnGerenciarVendas);
        
        // Botão Encomendas
        JButton btnEncomendas = criarBotaoAcao("Encomendas", 
            "Gerenciar encomendas de clientes", 
            new Color(255, 152, 0), 
            e -> abrirEncomendas());
        painelBotoes.add(btnEncomendas);
        
        // Botão Estoque
        JButton btnEstoque = criarBotaoAcao("Estoque", 
            "Verificar e gerenciar estoque", 
            new Color(155, 89, 182), 
            e -> abrirEstoque());
        painelBotoes.add(btnEstoque);
        
        painelAcoes.add(painelBotoes, BorderLayout.CENTER);
        
        return painelAcoes;
    }
    
    private JButton criarBotaoAcao(String texto, String tooltip, Color cor, ActionListener action) {
        // Botão com bordas arredondadas e sombra
        JButton botao = new JButton("<html><center>" + texto + "</center></html>") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Sombra
                g2.setColor(new Color(0, 0, 0, 40));
                g2.fillRoundRect(2, 2, getWidth() - 2, getHeight() - 2, 15, 15);
                
                // Fundo do botão
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 15, 15);
                
                // Texto
                g2.setColor(getForeground());
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                String text = getText().replaceAll("<[^>]*>", ""); // Remove HTML tags
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = (getHeight() + fm.getAscent()) / 2 - 2;
                g2.drawString(text, x, y);
                
                g2.dispose();
            }
        };
        
        botao.setFont(new Font("Arial", Font.BOLD, 14));
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));
        botao.setPreferredSize(new Dimension(180, 65));
        botao.setToolTipText(tooltip);
        botao.setOpaque(false);
        botao.setContentAreaFilled(false);
        botao.addActionListener(action);
        
        // Efeito hover melhorado
        Color corOriginal = cor;
        Color corHover = new Color(
            Math.max(0, cor.getRed() - 30),
            Math.max(0, cor.getGreen() - 30),
            Math.max(0, cor.getBlue() - 30)
        );
        
        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(corHover);
                botao.repaint();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(corOriginal);
                botao.repaint();
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                botao.setBackground(corHover.darker());
                botao.repaint();
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                botao.setBackground(corHover);
                botao.repaint();
            }
        });
        
        return botao;
    }
    
    private void abrirNovaVenda() {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal.fecharTodasJanelas();
            VendaView vendaView = new VendaView();
            TelaPrincipal.adicionarJanela(vendaView);
            vendaView.setVisible(true);
        });
    }
    
    private void abrirGerenciarVendas() {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal.fecharTodasJanelas();
            VendaView vendaView = new VendaView();
            TelaPrincipal.adicionarJanela(vendaView);
            vendaView.setVisible(true);
        });
    }
    
    private void abrirEncomendas() {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal.fecharTodasJanelas();
            EncomendaView encomendaView = new EncomendaView();
            TelaPrincipal.adicionarJanela(encomendaView);
            encomendaView.setVisible(true);
        });
    }
    
    private void abrirEstoque() {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal.fecharTodasJanelas();
            EstoqueView estoqueView = new EstoqueView();
            TelaPrincipal.adicionarJanela(estoqueView);
            estoqueView.setVisible(true);
        });
    }

    public void pararAtualizacaoAutomatica() {
        if (timer != null) {
            timer.stop();
        }
        if (controller != null) {
            controller.fechar();
        }
    }
}