/*
 * View para gerenciamento de Encomendas
 */
package view;

import controller.ClienteController;
import controller.EncomendaController;
import controller.EstoqueController;
import controller.ItemEncomendaController;
import controller.ProdutoController;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cliente;
import model.Encomenda;
import model.Estoque;
import model.ItemEncomenda;
import model.Produto;

/**
 *
 * @author jpescola
 */
public class EncomendaView extends javax.swing.JFrame {

    private EncomendaController encomendaController;
    private ClienteController clienteController;
    private ProdutoController produtoController;
    private EstoqueController estoqueController;
    private ItemEncomendaController itemController;
    private List<Encomenda> encomendas;
    private List<ItemEncomenda> itensEncomenda;
    private SimpleDateFormat dateFormat;
    private SimpleDateFormat dateFormatInput;
    private float valorTotal;

    public EncomendaView() {
        initComponents();
        encomendaController = new EncomendaController();
        clienteController = new ClienteController();
        produtoController = new ProdutoController();
        estoqueController = new EstoqueController();
        itemController = new ItemEncomendaController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        dateFormatInput = new SimpleDateFormat("dd/MM/yyyy");
        itensEncomenda = new ArrayList<>();
        valorTotal = 0.0f;
        
        loadClientes();
        loadProdutos();
        loadStatus();
        loadTabela();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(EncomendaView.this);
            }
        });
    }

    private void loadClientes() {
        List<Cliente> clientes = clienteController.listar();
        DefaultComboBoxModel<Cliente> model = new DefaultComboBoxModel<>();
        
        // Adicionar opção padrão
        model.addElement(null); // Representa "Selecione um cliente"
        
        if (clientes != null && !clientes.isEmpty()) {
            for (Cliente c : clientes) {
                model.addElement(c);
            }
        }
        cmbCliente.setModel(model);
        cmbCliente.setSelectedIndex(0); // Seleciona a opção vazia
    }

    private void loadProdutos() {
        List<Produto> todosProdutos = produtoController.listar();
        DefaultComboBoxModel<Produto> model = new DefaultComboBoxModel<>();
        
        // Adicionar opção padrão
        model.addElement(null); // Representa "Selecione um produto"
        
        if (todosProdutos != null && !todosProdutos.isEmpty()) {
            for (Produto p : todosProdutos) {
                // Para encomendas, permitir todos os produtos (mesmo sem estoque)
                model.addElement(p);
            }
        }
        cmbProduto.setModel(model);
        cmbProduto.setSelectedIndex(0); // Seleciona a opção vazia
    }

    private void loadStatus() {
        cmbStatus.removeAllItems();
        cmbStatus.addItem(null); // Representa "Todos os status"
        for (Encomenda.StatusEncomenda status : Encomenda.StatusEncomenda.values()) {
            cmbStatus.addItem(status);
        }
        cmbStatus.setSelectedIndex(0); // Seleciona a opção vazia
    }

    private void loadTabela() {
        encomendas = encomendaController.listar();
        DefaultTableModel model = (DefaultTableModel) tblEncomendas.getModel();
        model.setRowCount(0);
        
        if (encomendas != null && !encomendas.isEmpty()) {
            for (Encomenda e : encomendas) {
                model.addRow(new Object[]{
                    e.getId(),
                    dateFormat.format(e.getDataPedido()),
                    e.getDataRetirada() != null ? dateFormatInput.format(e.getDataRetirada()) : "",
                    e.getCliente() != null ? e.getCliente().getNome() : "N/A",
                    String.format("R$ %.2f", e.getValorTotal()),
                    e.getStatus().name()
                });
            }
        }
    }

    private void loadItensEncomenda() {
        DefaultTableModel model = (DefaultTableModel) tblItens.getModel();
        model.setRowCount(0);
        
        for (ItemEncomenda item : itensEncomenda) {
            // Verificar estoque atual
            Estoque estoque = estoqueController.buscarPorProduto(item.getProduto());
            String estoqueInfo = estoque != null ? " (Est: " + estoque.getQuantidade() + ")" : " (Sem estoque)";
            
            model.addRow(new Object[]{
                item.getProduto().getNome() + estoqueInfo,
                item.getQuantidade(),
                String.format("R$ %.2f", item.getPrecoUnitario()),
                String.format("R$ %.2f", item.getSubtotal())
            });
        }
        
        lblTotal.setText(String.format("Total: R$ %.2f", valorTotal));
    }

    private void adicionarItem() {
        try {
            Produto produto = (Produto) cmbProduto.getSelectedItem();
            if (produto == null) {
                JOptionPane.showMessageDialog(this, "Selecione um produto!");
                return;
            }

            String qtdStr = txtQuantidade.getText().trim();
            if (qtdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Informe a quantidade!");
                return;
            }

            int quantidade = Integer.parseInt(qtdStr);
            if (quantidade <= 0) {
                JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                return;
            }

            // Verificar se o produto já existe na encomenda
            ItemEncomenda itemExistente = null;
            for (ItemEncomenda item : itensEncomenda) {
                if (item.getProduto().getId() == produto.getId()) {
                    itemExistente = item;
                    break;
                }
            }

            if (itemExistente != null) {
                // Produto já existe, atualizar quantidade
                float subtotalAnterior = itemExistente.getSubtotal();
                itemExistente.setQuantidade(itemExistente.getQuantidade() + quantidade);
                itemExistente.calcularSubtotal();
                
                // Atualizar valor total
                valorTotal = valorTotal - subtotalAnterior + itemExistente.getSubtotal();
                
                System.out.println("Produto já existente atualizado: " + produto.getNome() + 
                                 " - Nova quantidade: " + itemExistente.getQuantidade());
            } else {
                // Produto novo, criar item
                ItemEncomenda novoItem = new ItemEncomenda();
                novoItem.setProduto(produto);
                novoItem.setQuantidade(quantidade);
                novoItem.setPrecoUnitario(produto.getPreco());
                novoItem.calcularSubtotal();

                itensEncomenda.add(novoItem);
                valorTotal += novoItem.getSubtotal();
                
                System.out.println("Novo item adicionado: " + produto.getNome() + 
                                 " - Quantidade: " + quantidade);
            }

            txtQuantidade.setText("");
            loadItensEncomenda();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantidade deve ser um número válido!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar item: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void removerItem() {
        int selectedRow = tblItens.getSelectedRow();
        if (selectedRow >= 0) {
            ItemEncomenda item = itensEncomenda.get(selectedRow);
            
            // Perguntar se quer remover tudo ou apenas uma quantidade
            String[] opcoes = {"Remover Tudo", "Remover Quantidade", "Cancelar"};
            int escolha = JOptionPane.showOptionDialog(this,
                "Como deseja remover o item: " + item.getProduto().getNome() + "?",
                "Remover Item",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]);
            
            if (escolha == 0) { // Remover tudo
                valorTotal -= item.getSubtotal();
                itensEncomenda.remove(selectedRow);
                
            } else if (escolha == 1) { // Remover quantidade específica
                String input = JOptionPane.showInputDialog(this, 
                    "Quantidade atual: " + item.getQuantidade() + "\nQuantidade a remover:",
                    "Remover Quantidade",
                    JOptionPane.QUESTION_MESSAGE);
                
                if (input != null && !input.trim().isEmpty()) {
                    try {
                        int quantidadeRemover = Integer.parseInt(input.trim());
                        if (quantidadeRemover <= 0) {
                            JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                            return;
                        }
                        
                        if (quantidadeRemover >= item.getQuantidade()) {
                            // Remover item inteiro
                            valorTotal -= item.getSubtotal();
                            itensEncomenda.remove(selectedRow);
                        } else {
                            // Reduzir quantidade
                            float subtotalAnterior = item.getSubtotal();
                            item.setQuantidade(item.getQuantidade() - quantidadeRemover);
                            item.calcularSubtotal();
                            valorTotal = valorTotal - subtotalAnterior + item.getSubtotal();
                        }
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Digite um valor numérico válido!");
                        return;
                    }
                }
            }
            
            loadItensEncomenda();
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um item para remover!");
        }
    }

    private void criarEncomenda() {
        try {
            Cliente cliente = (Cliente) cmbCliente.getSelectedItem();
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "Selecione um cliente!");
                return;
            }

            if (itensEncomenda.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Adicione pelo menos um item à encomenda!");
                return;
            }

            String dataRetiradaStr = txtDataRetirada.getText().trim();
            if (dataRetiradaStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Informe a data de retirada!");
                return;
            }

            Date dataRetirada;
            try {
                dataRetirada = dateFormatInput.parse(dataRetiradaStr);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(this, "Data inválida! Use o formato dd/MM/yyyy");
                return;
            }

            // Verificar se a data não é no passado
            Date hoje = new Date();
            if (dataRetirada.before(hoje)) {
                int resposta = JOptionPane.showConfirmDialog(this,
                    "A data de retirada é anterior à data atual.\nDeseja continuar mesmo assim?",
                    "Data no Passado",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
                
                if (resposta != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            String observacoes = txtObservacoes.getText().trim();

            Encomenda encomenda = new Encomenda();
            encomenda.setCliente(cliente);
            encomenda.setDataRetirada(dataRetirada);
            encomenda.setValorTotal(valorTotal);
            encomenda.setObservacoes(observacoes);
            encomenda.setStatus(Encomenda.StatusEncomenda.PENDENTE);

            // Primeiro, associar os itens à encomenda ANTES de salvar
            for (ItemEncomenda item : itensEncomenda) {
                item.setEncomenda(encomenda);
            }
            
            // Definir a lista de itens na encomenda
            encomenda.setItens(itensEncomenda);

            System.out.println("=== CRIANDO ENCOMENDA ===");
            System.out.println("Cliente: " + cliente.getNome());
            System.out.println("Data Retirada: " + dateFormatInput.format(dataRetirada));
            System.out.println("Valor Total: R$ " + valorTotal);
            System.out.println("Itens: " + itensEncomenda.size());

            if (encomendaController.salvarEncomendaCompleta(encomenda)) {
                System.out.println("Encomenda salva com ID: " + encomenda.getId());
                
                // Baixar do estoque (reservar produtos) - os itens já foram salvos pelo cascade
                for (ItemEncomenda item : itensEncomenda) {
                    if (!estoqueController.removerEstoque(item.getProduto(), item.getQuantidade())) {
                        System.out.println("Aviso: Não foi possível reservar estoque para: " + item.getProduto().getNome());
                    }
                }

                JOptionPane.showMessageDialog(this, 
                    "Encomenda criada com sucesso!\nEncomenda #" + encomenda.getId() + 
                    "\nData de retirada: " + dateFormatInput.format(dataRetirada));
                limparEncomenda();
                loadTabela();
                loadProdutos(); // Recarregar produtos para atualizar disponibilidade
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao criar encomenda!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void cancelarEncomenda() {
        int selectedRow = tblEncomendas.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma encomenda para cancelar!");
            return;
        }

        int id = (Integer) ((DefaultTableModel) tblEncomendas.getModel()).getValueAt(selectedRow, 0);
        Encomenda encomenda = encomendaController.get(id);
        
        if (encomenda == null) {
            JOptionPane.showMessageDialog(this, "Encomenda não encontrada!");
            return;
        }

        if (encomenda.getStatus() == Encomenda.StatusEncomenda.CANCELADA) {
            JOptionPane.showMessageDialog(this, "Esta encomenda já está cancelada!");
            return;
        }

        if (encomenda.getStatus() == Encomenda.StatusEncomenda.ENTREGUE) {
            JOptionPane.showMessageDialog(this, "Não é possível cancelar uma encomenda já entregue!");
            return;
        }

        int confirmacao = JOptionPane.showConfirmDialog(this,
            "Tem certeza que deseja cancelar a encomenda #" + encomenda.getId() + "?\n" +
            "Os itens serão devolvidos ao estoque.",
            "Confirmar Cancelamento",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (confirmacao == JOptionPane.YES_OPTION) {
            try {
                // Buscar itens da encomenda
                List<ItemEncomenda> itens = itemController.buscarPorEncomenda(encomenda.getId());
                
                if (itens == null) {
                    itens = new java.util.ArrayList<>();
                }
                
                System.out.println("Encontrados " + itens.size() + " itens para cancelar");
                
                // Devolver itens ao estoque
                boolean estoqueAtualizado = true;
                for (ItemEncomenda item : itens) {
                    if (item != null && item.getProduto() != null) {
                        if (!estoqueController.adicionarEstoque(item.getProduto(), item.getQuantidade())) {
                            estoqueAtualizado = false;
                            System.out.println("Erro ao devolver ao estoque: " + item.getProduto().getNome());
                        } else {
                            System.out.println("Devolvido ao estoque: " + item.getProduto().getNome() + " - Qtd: " + item.getQuantidade());
                        }
                    }
                }

                // Cancelar encomenda
                if (encomendaController.cancelarEncomenda(encomenda)) {
                    String mensagem = "Encomenda cancelada com sucesso!";
                    if (itens.size() > 0) {
                        mensagem += "\n" + itens.size() + " item(s) devolvido(s) ao estoque.";
                    }
                    if (!estoqueAtualizado) {
                        mensagem += "\n\nATENÇÃO: Houve problemas ao devolver alguns itens ao estoque.";
                    }
                    JOptionPane.showMessageDialog(this, mensagem);
                    loadTabela();
                    loadProdutos(); // Recarregar produtos
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao cancelar encomenda!");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro ao cancelar encomenda: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void marcarComoPronta() {
        int selectedRow = tblEncomendas.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma encomenda!");
            return;
        }

        int id = (Integer) ((DefaultTableModel) tblEncomendas.getModel()).getValueAt(selectedRow, 0);
        Encomenda encomenda = encomendaController.get(id);
        
        if (encomenda != null) {
            if (encomenda.getStatus() == Encomenda.StatusEncomenda.PENDENTE) {
                if (encomendaController.marcarComoPronta(encomenda)) {
                    JOptionPane.showMessageDialog(this, "Encomenda marcada como PRONTA!");
                    loadTabela();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao atualizar status!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Apenas encomendas PENDENTES podem ser marcadas como PRONTA!");
            }
        }
    }

    private void marcarComoEntregue() {
        int selectedRow = tblEncomendas.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma encomenda!");
            return;
        }

        int id = (Integer) ((DefaultTableModel) tblEncomendas.getModel()).getValueAt(selectedRow, 0);
        Encomenda encomenda = encomendaController.get(id);
        
        if (encomenda != null) {
            if (encomenda.getStatus() == Encomenda.StatusEncomenda.PRONTA) {
                if (encomendaController.marcarComoEntregue(encomenda)) {
                    JOptionPane.showMessageDialog(this, "Encomenda marcada como ENTREGUE!");
                    loadTabela();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao atualizar status!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Apenas encomendas PRONTAS podem ser marcadas como ENTREGUE!");
            }
        }
    }

    private void filtrarPorStatus() {
        Encomenda.StatusEncomenda statusSelecionado = (Encomenda.StatusEncomenda) cmbStatus.getSelectedItem();
        if (statusSelecionado == null) {
            loadTabela();
            return;
        }

        List<Encomenda> encomendasFiltradas = encomendaController.buscarPorStatus(statusSelecionado);
        DefaultTableModel model = (DefaultTableModel) tblEncomendas.getModel();
        model.setRowCount(0);
        
        if (encomendasFiltradas != null && !encomendasFiltradas.isEmpty()) {
            for (Encomenda e : encomendasFiltradas) {
                model.addRow(new Object[]{
                    e.getId(),
                    dateFormat.format(e.getDataPedido()),
                    e.getDataRetirada() != null ? dateFormatInput.format(e.getDataRetirada()) : "",
                    e.getCliente() != null ? e.getCliente().getNome() : "N/A",
                    String.format("R$ %.2f", e.getValorTotal()),
                    e.getStatus().name()
                });
            }
        }
    }

    private void limparEncomenda() {
        itensEncomenda.clear();
        valorTotal = 0.0f;
        txtQuantidade.setText("");
        txtDataRetirada.setText("");
        txtObservacoes.setText("");
        if (cmbCliente.getItemCount() > 0) cmbCliente.setSelectedIndex(0);
        loadItensEncomenda();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmbCliente = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        txtDataRetirada = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtObservacoes = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cmbProduto = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        btnRemover = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblItens = new javax.swing.JTable();
        lblTotal = new javax.swing.JLabel();
        btnCriar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        btnFiltrar = new javax.swing.JButton();
        btnTodos = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnPronta = new javax.swing.JButton();
        btnEntregue = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblEncomendas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gerenciar Encomendas - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/Calendar_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da Encomenda"));

        jLabel1.setText("Cliente:");

        jLabel2.setText("Data Retirada (dd/MM/yyyy):");

        jLabel3.setText("Observações:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbCliente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDataRetirada))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtObservacoes)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtDataRetirada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtObservacoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens da Encomenda"));

        jLabel4.setText("Produto:");

        jLabel5.setText("Quantidade:");

        btnAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Add_16x16.png")));
        btnAdicionar.setText("Adicionar");
        btnAdicionar.setBackground(new java.awt.Color(46, 204, 113));
        btnAdicionar.setForeground(java.awt.Color.WHITE);
        btnAdicionar.setFocusPainted(false);
        btnAdicionar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        btnRemover.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Remove_16x16.png")));
        btnRemover.setText("Remover");
        btnRemover.setBackground(new java.awt.Color(231, 76, 60));
        btnRemover.setForeground(java.awt.Color.WHITE);
        btnRemover.setFocusPainted(false);
        btnRemover.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        tblItens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Preço Unit.", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblItens);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotal.setText("Total: R$ 0,00");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbProduto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAdicionar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRemover))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblTotal)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdicionar)
                    .addComponent(btnRemover))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnCriar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Check_16x16.png")));
        btnCriar.setText("Criar Encomenda");
        btnCriar.setBackground(new java.awt.Color(39, 174, 96));
        btnCriar.setForeground(java.awt.Color.WHITE);
        btnCriar.setFocusPainted(false);
        btnCriar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnCriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCriarActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Gerenciar Encomendas"));

        jLabel6.setText("Filtrar por Status:");

        btnFiltrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Find_16x16.png")));
        btnFiltrar.setText("Filtrar");
        btnFiltrar.setBackground(new java.awt.Color(52, 152, 219));
        btnFiltrar.setForeground(java.awt.Color.WHITE);
        btnFiltrar.setFocusPainted(false);
        btnFiltrar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltrarActionPerformed(evt);
            }
        });

        btnTodos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Refresh_16x16.png")));
        btnTodos.setText("Mostrar Todos");
        btnTodos.setBackground(new java.awt.Color(149, 165, 166));
        btnTodos.setForeground(java.awt.Color.WHITE);
        btnTodos.setFocusPainted(false);
        btnTodos.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTodosActionPerformed(evt);
            }
        });

        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnCancelar.setText("Cancelar");
        btnCancelar.setBackground(new java.awt.Color(231, 76, 60));
        btnCancelar.setForeground(java.awt.Color.WHITE);
        btnCancelar.setFocusPainted(false);
        btnCancelar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnPronta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Check_16x16.png")));
        btnPronta.setText("Marcar Pronta");
        btnPronta.setBackground(new java.awt.Color(46, 204, 113));
        btnPronta.setForeground(java.awt.Color.WHITE);
        btnPronta.setFocusPainted(false);
        btnPronta.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnPronta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProntaActionPerformed(evt);
            }
        });

        btnEntregue.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Check_16x16.png")));
        btnEntregue.setText("Marcar Entregue");
        btnEntregue.setBackground(new java.awt.Color(39, 174, 96));
        btnEntregue.setForeground(java.awt.Color.WHITE);
        btnEntregue.setFocusPainted(false);
        btnEntregue.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnEntregue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntregueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFiltrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTodos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPronta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEntregue)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFiltrar)
                    .addComponent(btnTodos)
                    .addComponent(btnCancelar)
                    .addComponent(btnPronta)
                    .addComponent(btnEntregue))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblEncomendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Data Pedido", "Data Retirada", "Cliente", "Valor Total", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblEncomendas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCriar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCriar)
                    .addComponent(btnLimpar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        adicionarItem();
    }                                            

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {                                           
        removerItem();
    }                                          

    private void btnCriarActionPerformed(java.awt.event.ActionEvent evt) {                                         
        criarEncomenda();
    }                                        

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparEncomenda();
    }                                         

    private void btnFiltrarActionPerformed(java.awt.event.ActionEvent evt) {                                           
        filtrarPorStatus();
    }                                          

    private void btnTodosActionPerformed(java.awt.event.ActionEvent evt) {                                         
        loadTabela();
    }                                        

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {                                            
        cancelarEncomenda();
    }                                           

    private void btnProntaActionPerformed(java.awt.event.ActionEvent evt) {                                          
        marcarComoPronta();
    }                                         

    private void btnEntregueActionPerformed(java.awt.event.ActionEvent evt) {                                            
        marcarComoEntregue();
    }                                           

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnCriar;
    private javax.swing.JButton btnEntregue;
    private javax.swing.JButton btnFiltrar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPronta;
    private javax.swing.JButton btnRemover;
    private javax.swing.JButton btnTodos;
    private javax.swing.JComboBox<Cliente> cmbCliente;
    private javax.swing.JComboBox<Produto> cmbProduto;
    private javax.swing.JComboBox<Encomenda.StatusEncomenda> cmbStatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblEncomendas;
    private javax.swing.JTable tblItens;
    private javax.swing.JTextField txtDataRetirada;
    private javax.swing.JTextField txtObservacoes;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JLabel lblTotal;
    // End of variables declaration                   
}