/*
 * View para gerenciamento de Estoque
 */
package view;

import controller.EstoqueController;
import controller.ProdutoController;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Estoque;
import model.Produto;

/**
 *
 * @author jpescola
 */
public class EstoqueView extends javax.swing.JFrame {

    private EstoqueController estoqueController;
    private ProdutoController produtoController;
    private DefaultTableModel tableModel;
    private SimpleDateFormat dateFormat;
    private Estoque estoqueSelecionado;

    public EstoqueView() {
        initComponents();
        estoqueController = new EstoqueController();
        produtoController = new ProdutoController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        setupTable();
        carregarProdutos();
        carregarEstoque();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(EstoqueView.this);
            }
        });
    }

    private void setupTable() {
        tableModel = new DefaultTableModel(new Object[][]{}, 
            new String[]{"ID", "Produto", "Quantidade", "Qtd Mínima", "Status", "Última Atualização"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaEstoque.setModel(tableModel);
    }

    private void carregarProdutos() {
        try {
            List<Produto> produtos = produtoController.listar();
            DefaultComboBoxModel<Produto> model = new DefaultComboBoxModel<>();
            
            // Adicionar opção padrão
            model.addElement(null); // Representa "Selecione um produto"
            
            if (produtos != null && !produtos.isEmpty()) {
                for (Produto produto : produtos) {
                    model.addElement(produto);
                }
            }
            comboProduto.setModel(model);
            comboProduto.setSelectedIndex(0); // Seleciona a opção vazia
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar produtos: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void carregarEstoque() {
        tableModel.setRowCount(0);
        try {
            List<Estoque> estoques = estoqueController.listar();
            if (estoques != null && !estoques.isEmpty()) {
                for (Estoque e : estoques) {
                    String status = e.isEstoqueBaixo() ? "BAIXO" : "OK";
                    Object[] row = {
                        e.getId(),
                        e.getProduto() != null ? e.getProduto().getNome() : "N/A",
                        e.getQuantidade(),
                        e.getQuantidadeMinima(),
                        status,
                        e.getDataUltimaAtualizacao() != null ? dateFormat.format(e.getDataUltimaAtualizacao()) : ""
                    };
                    tableModel.addRow(row);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar estoque: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void limparCampos() {
        if (comboProduto.getItemCount() > 0) {
            comboProduto.setSelectedIndex(0);
        }
        txtQuantidade.setText("");
        txtQuantidadeMinima.setText("");
        estoqueSelecionado = null;
        btnSalvar.setText("Salvar");
    }

    private boolean validarCampos() {
        if (comboProduto.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!");
            return false;
        }
        if (txtQuantidade.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantidade é obrigatória!");
            return false;
        }
        if (txtQuantidadeMinima.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quantidade mínima é obrigatória!");
            return false;
        }
        try {
            int quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            int quantidadeMinima = Integer.parseInt(txtQuantidadeMinima.getText().trim());
            if (quantidade < 0 || quantidadeMinima < 0) {
                JOptionPane.showMessageDialog(this, "Quantidades não podem ser negativas!");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Digite valores numéricos válidos!");
            return false;
        }
        return true;
    }

    private void salvarEstoque() {
        if (!validarCampos()) return;

        try {
            Produto produto = (Produto) comboProduto.getSelectedItem();
            int quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            int quantidadeMinima = Integer.parseInt(txtQuantidadeMinima.getText().trim());

            Estoque estoque = estoqueSelecionado;
            if (estoque == null) {
                // Verificar se já existe estoque para este produto
                estoque = estoqueController.buscarPorProduto(produto);
                if (estoque == null) {
                    estoque = new Estoque();
                }
            }

            estoque.setProduto(produto);
            estoque.setQuantidade(quantidade);
            estoque.setQuantidadeMinima(quantidadeMinima);

            if (estoqueController.salvar(estoque)) {
                JOptionPane.showMessageDialog(this, "Estoque salvo com sucesso!");
                limparCampos();
                carregarEstoque();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar estoque!");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Valores numéricos inválidos!");
        }
    }

    private void editarEstoque() {
        int selectedRow = tabelaEstoque.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um item do estoque para editar!");
            return;
        }

        int id = (Integer) tableModel.getValueAt(selectedRow, 0);
        estoqueSelecionado = estoqueController.get(id);
        
        if (estoqueSelecionado != null) {
            comboProduto.setSelectedItem(estoqueSelecionado.getProduto());
            txtQuantidade.setText(String.valueOf(estoqueSelecionado.getQuantidade()));
            txtQuantidadeMinima.setText(String.valueOf(estoqueSelecionado.getQuantidadeMinima()));
            btnSalvar.setText("Atualizar");
        }
    }

    private void excluirEstoque() {
        int selectedRow = tabelaEstoque.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um item do estoque para excluir!");
            return;
        }

        int confirmacao = JOptionPane.showConfirmDialog(this, 
            "Tem certeza que deseja excluir este item do estoque?", 
            "Confirmar Exclusão", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacao == JOptionPane.YES_OPTION) {
            int id = (Integer) tableModel.getValueAt(selectedRow, 0);
            Estoque estoque = estoqueController.get(id);
            
            if (estoque != null && estoqueController.excluir(estoque)) {
                JOptionPane.showMessageDialog(this, "Item do estoque excluído com sucesso!");
                limparCampos();
                carregarEstoque();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir item do estoque!");
            }
        }
    }

    private void adicionarQuantidade() {
        if (comboProduto.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!");
            return;
        }

        Produto produto = (Produto) comboProduto.getSelectedItem();
        
        // Verificar se já existe estoque para mostrar quantidade atual
        Estoque estoqueAtual = estoqueController.buscarPorProduto(produto);
        String mensagem;
        if (estoqueAtual != null) {
            mensagem = "Quantidade atual: " + estoqueAtual.getQuantidade() + "\nQuantidade a adicionar:";
        } else {
            mensagem = "Este produto não possui estoque cadastrado.\nQuantidade inicial a adicionar:";
        }

        String input = JOptionPane.showInputDialog(this, mensagem, "Adicionar ao Estoque", JOptionPane.QUESTION_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            try {
                int quantidade = Integer.parseInt(input.trim());
                if (quantidade <= 0) {
                    JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                    return;
                }

                System.out.println("=== ADICIONANDO QUANTIDADE ===");
                System.out.println("Produto: " + produto.getNome() + " (ID: " + produto.getId() + ")");
                System.out.println("Quantidade a adicionar: " + quantidade);
                
                if (estoqueController.adicionarEstoque(produto, quantidade)) {
                    String sucessoMsg;
                    if (estoqueAtual != null) {
                        int novaQuantidade = estoqueAtual.getQuantidade() + quantidade;
                        sucessoMsg = "Quantidade adicionada com sucesso!\n" +
                                   "Quantidade anterior: " + estoqueAtual.getQuantidade() + "\n" +
                                   "Quantidade adicionada: " + quantidade + "\n" +
                                   "Nova quantidade: " + novaQuantidade;
                    } else {
                        sucessoMsg = "Estoque criado com sucesso!\nQuantidade inicial: " + quantidade;
                    }
                    JOptionPane.showMessageDialog(this, sucessoMsg);
                    carregarEstoque();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao adicionar quantidade!");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Digite um valor numérico válido!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro inesperado: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void removerQuantidade() {
        if (comboProduto.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!");
            return;
        }

        Produto produto = (Produto) comboProduto.getSelectedItem();
        
        // Verificar se o produto tem estoque cadastrado
        Estoque estoqueAtual = estoqueController.buscarPorProduto(produto);
        if (estoqueAtual == null) {
            JOptionPane.showMessageDialog(this, "Este produto não possui estoque cadastrado!");
            return;
        }

        String mensagem = "Quantidade disponível: " + estoqueAtual.getQuantidade() + "\nQuantidade a remover:";
        String input = JOptionPane.showInputDialog(this, mensagem, "Remover do Estoque", JOptionPane.QUESTION_MESSAGE);
        
        if (input != null && !input.trim().isEmpty()) {
            try {
                int quantidade = Integer.parseInt(input.trim());
                if (quantidade <= 0) {
                    JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                    return;
                }

                if (quantidade > estoqueAtual.getQuantidade()) {
                    JOptionPane.showMessageDialog(this, 
                        "Quantidade insuficiente!\n" +
                        "Disponível: " + estoqueAtual.getQuantidade() + "\n" +
                        "Solicitado: " + quantidade);
                    return;
                }

                if (estoqueController.removerEstoque(produto, quantidade)) {
                    JOptionPane.showMessageDialog(this, "Quantidade removida com sucesso!");
                    carregarEstoque();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao remover quantidade!");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Digite um valor numérico válido!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erro inesperado: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void mostrarEstoqueBaixo() {
        tableModel.setRowCount(0);
        try {
            List<Estoque> estoquesBaixos = estoqueController.listarEstoqueBaixo();
            
            if (estoquesBaixos == null || estoquesBaixos.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Não há produtos com estoque baixo!");
                carregarEstoque();
                return;
            }

            for (Estoque e : estoquesBaixos) {
                Object[] row = {
                    e.getId(),
                    e.getProduto() != null ? e.getProduto().getNome() : "N/A",
                    e.getQuantidade(),
                    e.getQuantidadeMinima(),
                    "BAIXO",
                    e.getDataUltimaAtualizacao() != null ? dateFormat.format(e.getDataUltimaAtualizacao()) : ""
                };
                tableModel.addRow(row);
            }
            
            JOptionPane.showMessageDialog(this, "Mostrando " + estoquesBaixos.size() + " produto(s) com estoque baixo!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar estoque baixo: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        comboProduto = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtQuantidadeMinima = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnAdicionar = new javax.swing.JButton();
        btnRemover = new javax.swing.JButton();
        btnEstoqueBaixo = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaEstoque = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gestão de Estoque - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/Hard Disk_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Estoque"));

        jLabel1.setText("Produto:");

        jLabel2.setText("Quantidade:");

        jLabel3.setText("Quantidade Mínima:");

        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Save_16x16.png")));
        btnSalvar.setText("Salvar");
        btnSalvar.setBackground(new java.awt.Color(46, 204, 113));
        btnSalvar.setForeground(java.awt.Color.WHITE);
        btnSalvar.setFocusPainted(false);
        btnSalvar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Edit_16x16.png")));
        btnEditar.setText("Editar");
        btnEditar.setBackground(new java.awt.Color(52, 152, 219));
        btnEditar.setForeground(java.awt.Color.WHITE);
        btnEditar.setFocusPainted(false);
        btnEditar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Delete_16x16.png")));
        btnExcluir.setText("Excluir");
        btnExcluir.setBackground(new java.awt.Color(231, 76, 60));
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFocusPainted(false);
        btnExcluir.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(comboProduto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQuantidade))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQuantidadeMinima))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEditar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(comboProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtQuantidadeMinima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnEditar)
                    .addComponent(btnExcluir)
                    .addComponent(btnLimpar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Operações de Estoque"));

        btnAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Add_16x16.png")));
        btnAdicionar.setText("Adicionar Quantidade");
        btnAdicionar.setBackground(new java.awt.Color(46, 204, 113));
        btnAdicionar.setForeground(java.awt.Color.WHITE);
        btnAdicionar.setFocusPainted(false);
        btnAdicionar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        btnRemover.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Remove_16x16.png")));
        btnRemover.setText("Remover Quantidade");
        btnRemover.setBackground(new java.awt.Color(231, 76, 60));
        btnRemover.setForeground(java.awt.Color.WHITE);
        btnRemover.setFocusPainted(false);
        btnRemover.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        btnEstoqueBaixo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Stock Index Down_16x16.png")));
        btnEstoqueBaixo.setText("Estoque Baixo");
        btnEstoqueBaixo.setBackground(new java.awt.Color(255, 152, 0));
        btnEstoqueBaixo.setForeground(java.awt.Color.WHITE);
        btnEstoqueBaixo.setFocusPainted(false);
        btnEstoqueBaixo.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnEstoqueBaixo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEstoqueBaixoActionPerformed(evt);
            }
        });

        btnAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Refresh_16x16.png")));
        btnAtualizar.setText("Atualizar Lista");
        btnAtualizar.setBackground(new java.awt.Color(52, 152, 219));
        btnAtualizar.setForeground(java.awt.Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAdicionar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRemover)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEstoqueBaixo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAtualizar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdicionar)
                    .addComponent(btnRemover)
                    .addComponent(btnEstoqueBaixo)
                    .addComponent(btnAtualizar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Lista de Estoque"));

        tabelaEstoque.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Produto", "Quantidade", "Qtd Mínima", "Status", "Última Atualização"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaEstoque);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        salvarEstoque();
    }                                         

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        editarEstoque();
    }                                         

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {                                           
        excluirEstoque();
    }                                          

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparCampos();
    }                                         

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        adicionarQuantidade();
    }                                            

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {                                           
        removerQuantidade();
    }                                          

    private void btnEstoqueBaixoActionPerformed(java.awt.event.ActionEvent evt) {                                                
        mostrarEstoqueBaixo();
    }                                               

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        carregarEstoque();
    }                                            

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEstoqueBaixo;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnRemover;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<Produto> comboProduto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaEstoque;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JTextField txtQuantidadeMinima;
    // End of variables declaration                   
}