/*
 * View para gerenciamento de Funcionários
 */
package view;

import controller.FuncionarioController;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Funcionario;

/**
 *
 * @author jpescola
 */
public class FuncionarioView extends javax.swing.JFrame {

    private FuncionarioController controller;
    private DefaultTableModel tableModel;
    private SimpleDateFormat dateFormat;
    private Funcionario funcionarioSelecionado;

    public FuncionarioView() {
        initComponents();
        controller = new FuncionarioController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        setupTable();
        carregarFuncionarios();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(FuncionarioView.this);
            }
        });
    }

    private void setupTable() {
        tableModel = new DefaultTableModel(new Object[][]{}, 
            new String[]{"ID", "Nome", "Telefone", "Email", "Data Início", "Salário", "Dia Pagamento"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabelaFuncionarios.setModel(tableModel);
    }

    private void carregarFuncionarios() {
        tableModel.setRowCount(0);
        List<Funcionario> funcionarios = controller.listar();
        for (Funcionario f : funcionarios) {
            Object[] row = {
                f.getId(),
                f.getNome(),
                f.getTelefone(),
                f.getEmail(),
                f.getDataInicio() != null ? dateFormat.format(f.getDataInicio()) : "",
                f.getSalario() != null ? "R$ " + f.getSalario().toString() : "",
                f.getDiaPagamento()
            };
            tableModel.addRow(row);
        }
    }

    private void limparCampos() {
        txtNome.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        txtDataInicio.setText("");
        txtDataDesligamento.setText("");
        txtSalario.setText("");
        txtDiaPagamento.setText("");
        funcionarioSelecionado = null;
        btnSalvar.setText("Salvar");
    }

    private boolean validarCampos() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome é obrigatório!");
            return false;
        }
        if (txtTelefone.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Telefone é obrigatório!");
            return false;
        }
        if (txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email é obrigatório!");
            return false;
        }
        if (txtDataInicio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Data de início é obrigatória!");
            return false;
        }
        if (txtSalario.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Salário é obrigatório!");
            return false;
        }
        if (txtDiaPagamento.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Dia de pagamento é obrigatório!");
            return false;
        }
        return true;
    }

    private void salvarFuncionario() {
        if (!validarCampos()) return;

        try {
            Funcionario funcionario = funcionarioSelecionado != null ? funcionarioSelecionado : new Funcionario();
            
            funcionario.setNome(txtNome.getText().trim());
            funcionario.setEndereco(txtEndereco.getText().trim());
            funcionario.setTelefone(txtTelefone.getText().trim());
            funcionario.setEmail(txtEmail.getText().trim());
            
            // Parse data de início
            Date dataInicio = dateFormat.parse(txtDataInicio.getText().trim());
            funcionario.setDataInicio(dataInicio);
            
            // Parse data de desligamento (opcional)
            if (!txtDataDesligamento.getText().trim().isEmpty()) {
                Date dataDesligamento = dateFormat.parse(txtDataDesligamento.getText().trim());
                funcionario.setDataDesligamento(dataDesligamento);
            }
            
            // Parse salário
            BigDecimal salario = new BigDecimal(txtSalario.getText().trim().replace(",", "."));
            funcionario.setSalario(salario);
            
            // Parse dia de pagamento
            int diaPagamento = Integer.parseInt(txtDiaPagamento.getText().trim());
            if (diaPagamento < 1 || diaPagamento > 31) {
                JOptionPane.showMessageDialog(this, "Dia de pagamento deve estar entre 1 e 31!");
                return;
            }
            funcionario.setDiaPagamento(diaPagamento);

            if (controller.salvar(funcionario)) {
                JOptionPane.showMessageDialog(this, "Funcionário salvo com sucesso!");
                limparCampos();
                carregarFuncionarios();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar funcionário!");
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido! Use dd/MM/yyyy");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Valor numérico inválido!");
        }
    }

    private void editarFuncionario() {
        int selectedRow = tabelaFuncionarios.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário para editar!");
            return;
        }

        int id = (Integer) tableModel.getValueAt(selectedRow, 0);
        funcionarioSelecionado = controller.get(id);
        
        if (funcionarioSelecionado != null) {
            txtNome.setText(funcionarioSelecionado.getNome());
            txtEndereco.setText(funcionarioSelecionado.getEndereco());
            txtTelefone.setText(funcionarioSelecionado.getTelefone());
            txtEmail.setText(funcionarioSelecionado.getEmail());
            
            if (funcionarioSelecionado.getDataInicio() != null) {
                txtDataInicio.setText(dateFormat.format(funcionarioSelecionado.getDataInicio()));
            }
            if (funcionarioSelecionado.getDataDesligamento() != null) {
                txtDataDesligamento.setText(dateFormat.format(funcionarioSelecionado.getDataDesligamento()));
            }
            if (funcionarioSelecionado.getSalario() != null) {
                txtSalario.setText(funcionarioSelecionado.getSalario().toString());
            }
            txtDiaPagamento.setText(String.valueOf(funcionarioSelecionado.getDiaPagamento()));
            
            btnSalvar.setText("Atualizar");
        }
    }

    private void excluirFuncionario() {
        int selectedRow = tabelaFuncionarios.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário para excluir!");
            return;
        }

        int confirmacao = JOptionPane.showConfirmDialog(this, 
            "Tem certeza que deseja excluir este funcionário?", 
            "Confirmar Exclusão", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirmacao == JOptionPane.YES_OPTION) {
            int id = (Integer) tableModel.getValueAt(selectedRow, 0);
            Funcionario funcionario = controller.get(id);
            
            if (funcionario != null && controller.excluir(funcionario)) {
                JOptionPane.showMessageDialog(this, "Funcionário excluído com sucesso!");
                limparCampos();
                carregarFuncionarios();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir funcionário!");
            }
        }
    }

    private void buscarFuncionario() {
        String nome = txtBuscar.getText().trim();
        if (nome.isEmpty()) {
            carregarFuncionarios();
            return;
        }

        tableModel.setRowCount(0);
        List<Funcionario> funcionarios = controller.buscarPorNome(nome);
        for (Funcionario f : funcionarios) {
            Object[] row = {
                f.getId(),
                f.getNome(),
                f.getTelefone(),
                f.getEmail(),
                f.getDataInicio() != null ? dateFormat.format(f.getDataInicio()) : "",
                f.getSalario() != null ? "R$ " + f.getSalario().toString() : "",
                f.getDiaPagamento()
            };
            tableModel.addRow(row);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtDataInicio = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDataDesligamento = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtSalario = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtDiaPagamento = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaFuncionarios = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gestão de Funcionários - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/User_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Funcionário"));

        jLabel1.setText("Nome:");

        jLabel2.setText("Endereço:");

        jLabel3.setText("Telefone:");

        jLabel4.setText("Email:");

        jLabel5.setText("Data Início (dd/MM/yyyy):");

        jLabel6.setText("Data Desligamento (dd/MM/yyyy):");

        jLabel7.setText("Salário:");

        jLabel8.setText("Dia Pagamento (1-31):");

        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Save_16x16.png")));
        btnSalvar.setText("Salvar");
        btnSalvar.setBackground(new java.awt.Color(46, 204, 113));
        btnSalvar.setForeground(java.awt.Color.WHITE);
        btnSalvar.setFocusPainted(false);
        btnSalvar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Edit_16x16.png")));
        btnEditar.setText("Editar");
        btnEditar.setBackground(new java.awt.Color(52, 152, 219));
        btnEditar.setForeground(java.awt.Color.WHITE);
        btnEditar.setFocusPainted(false);
        btnEditar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Delete_16x16.png")));
        btnExcluir.setText("Excluir");
        btnExcluir.setBackground(new java.awt.Color(231, 76, 60));
        btnExcluir.setForeground(java.awt.Color.WHITE);
        btnExcluir.setFocusPainted(false);
        btnExcluir.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNome))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEndereco))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmail)
                            .addComponent(txtTelefone)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDataDesligamento)
                            .addComponent(txtDataInicio)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDiaPagamento)
                            .addComponent(txtSalario)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEditar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtDataDesligamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtDiaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalvar)
                    .addComponent(btnEditar)
                    .addComponent(btnExcluir)
                    .addComponent(btnLimpar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Lista de Funcionários"));

        jLabel9.setText("Buscar por nome:");

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Search_16x16.png")));
        btnBuscar.setText("Buscar");
        btnBuscar.setBackground(new java.awt.Color(52, 152, 219));
        btnBuscar.setForeground(java.awt.Color.WHITE);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tabelaFuncionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Telefone", "Email", "Data Início", "Salário", "Dia Pagamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaFuncionarios);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        salvarFuncionario();
    }                                         

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        editarFuncionario();
    }                                         

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {                                           
        excluirFuncionario();
    }                                          

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparCampos();
    }                                         

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        buscarFuncionario();
    }                                         

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaFuncionarios;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDataDesligamento;
    private javax.swing.JTextField txtDataInicio;
    private javax.swing.JTextField txtDiaPagamento;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration                   
}