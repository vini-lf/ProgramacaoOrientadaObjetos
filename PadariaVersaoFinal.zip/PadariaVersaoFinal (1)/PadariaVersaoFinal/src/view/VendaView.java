/*
 * View para gerenciamento de Vendas
 */
package view;

import controller.ClienteController;
import controller.EncomendaController;
import controller.EstoqueController;
import controller.ItemEncomendaController;
import controller.ItemVendaController;
import controller.ProdutoController;
import controller.VendaController;
import util.CupomFiscal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Cliente;
import model.Encomenda;
import model.Estoque;
import model.ItemEncomenda;
import model.ItemVenda;
import model.Produto;
import model.Venda;

/**
 *
 * @author jpescola
 */
public class VendaView extends javax.swing.JFrame {

    private VendaController vendaController;
    private ClienteController clienteController;
    private ProdutoController produtoController;
    private EstoqueController estoqueController;
    private ItemVendaController itemController;
    private EncomendaController encomendaController;
    private ItemEncomendaController itemEncomendaController;
    private List<Venda> vendas;
    private List<ItemVenda> itensVenda;
    private SimpleDateFormat dateFormat;
    private float valorTotal;
    private Encomenda encomendaSelecionada;
    private List<ItemEncomenda> itensEncomenda;

    /**
     * Creates new form VendaView
     */
    public VendaView() {
        initComponents();
        vendaController = new VendaController();
        clienteController = new ClienteController();
        produtoController = new ProdutoController();
        estoqueController = new EstoqueController();
        itemController = new ItemVendaController();
        encomendaController = new EncomendaController();
        itemEncomendaController = new ItemEncomendaController();
        dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        itensVenda = new ArrayList<>();
        valorTotal = 0.0f;
        encomendaSelecionada = null;
        itensEncomenda = new ArrayList<>();
        
        loadClientes();
        loadProdutos();
        loadFormasPagamento();
        loadTabela();
        
        // Adicionar listener para remover da lista quando fechar
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                TelaPrincipal.removerJanela(VendaView.this);
            }
        });
    }

    private void loadClientes() {
        List<Cliente> clientes = clienteController.listar();
        DefaultComboBoxModel<Cliente> model = new DefaultComboBoxModel<>();
        
        // Adicionar opção padrão
        model.addElement(null); // Representa "Selecione um cliente"
        
        if (clientes != null && !clientes.isEmpty()) {
            for (Cliente c : clientes) {
                model.addElement(c);
            }
        }
        cmbCliente.setModel(model);
        cmbCliente.setSelectedIndex(0); // Seleciona a opção vazia
    }

    private void loadProdutos() {
        List<Produto> todosProdutos = produtoController.listar();
        DefaultComboBoxModel<Produto> model = new DefaultComboBoxModel<>();
        
        // Adicionar opção padrão
        model.addElement(null); // Representa "Selecione um produto"
        
        if (todosProdutos != null && !todosProdutos.isEmpty()) {
            for (Produto p : todosProdutos) {
                // Verificar se o produto tem estoque disponível
                Estoque estoque = estoqueController.buscarPorProduto(p);
                if (estoque != null && estoque.getQuantidade() > 0 && !estoque.isEstoqueBaixo()) {
                    model.addElement(p);
                }
            }
        }
        cmbProduto.setModel(model);
        cmbProduto.setSelectedIndex(0); // Seleciona a opção vazia
        
        // Mostrar informação sobre produtos disponíveis
        int totalProdutos = todosProdutos != null ? todosProdutos.size() : 0;
        int produtosDisponiveis = model.getSize() - 1; // -1 porque temos a opção "Selecione"
        System.out.println("Produtos carregados: " + produtosDisponiveis + " de " + totalProdutos + " (apenas com estoque OK)");
    }

    private void loadFormasPagamento() {
        cmbFormaPagamento.removeAllItems();
        cmbFormaPagamento.addItem("Selecione forma de pagamento");
        cmbFormaPagamento.addItem("Dinheiro");
        cmbFormaPagamento.addItem("Cartão de Débito");
        cmbFormaPagamento.addItem("Cartão de Crédito");
        cmbFormaPagamento.addItem("PIX");
        cmbFormaPagamento.addItem("Cheque");
        cmbFormaPagamento.setSelectedIndex(0); // Seleciona a opção vazia
    }

    private void loadTabela() {
        vendas = vendaController.listar();
        DefaultTableModel model = (DefaultTableModel) tblVendas.getModel();
        model.setRowCount(0);
        
        if (vendas != null && !vendas.isEmpty()) {
            for (Venda v : vendas) {
                model.addRow(new Object[]{
                    v.getId(),
                    dateFormat.format(v.getDataVenda()),
                    v.getCliente().getNome(),
                    String.format("R$ %.2f", v.getValorTotal()),
                    v.getFormaPagamento()
                });
            }
        }
    }

    private void loadItensVenda() {
        DefaultTableModel model = (DefaultTableModel) tblItens.getModel();
        model.setRowCount(0);
        
        for (ItemVenda item : itensVenda) {
            // Verificar estoque atual
            Estoque estoque = estoqueController.buscarPorProduto(item.getProduto());
            String estoqueInfo = estoque != null ? " (Est: " + estoque.getQuantidade() + ")" : " (Sem estoque)";
            
            // Verificar se o item é da encomenda
            String origemInfo = "";
            int quantidadeEncomenda = 0;
            int quantidadeExtra = item.getQuantidade();
            
            if (encomendaSelecionada != null && itensEncomenda != null) {
                for (ItemEncomenda itemEnc : itensEncomenda) {
                    if (itemEnc.getProduto().getId() == item.getProduto().getId()) {
                        quantidadeEncomenda = itemEnc.getQuantidade();
                        quantidadeExtra = item.getQuantidade() - quantidadeEncomenda;
                        break;
                    }
                }
                
                if (quantidadeEncomenda > 0) {
                    if (quantidadeExtra > 0) {
                        origemInfo = " [Enc:" + quantidadeEncomenda + " +Extra:" + quantidadeExtra + "]";
                    } else {
                        origemInfo = " [Encomenda:" + quantidadeEncomenda + "]";
                    }
                } else {
                    origemInfo = " [Extra:" + quantidadeExtra + "]";
                }
            }
            
            model.addRow(new Object[]{
                item.getProduto().getNome() + estoqueInfo + origemInfo,
                item.getQuantidade(),
                String.format("R$ %.2f", item.getPrecoUnitario()),
                String.format("R$ %.2f", item.getSubtotal())
            });
        }
        
        lblTotal.setText(String.format("Total: R$ %.2f", valorTotal));
    }

    private void adicionarItem() {
        try {
            Produto produto = (Produto) cmbProduto.getSelectedItem();
            if (produto == null) {
                JOptionPane.showMessageDialog(this, "Selecione um produto!");
                return;
            }

            String qtdStr = txtQuantidade.getText().trim();
            if (qtdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Informe a quantidade!");
                return;
            }

            int quantidade = Integer.parseInt(qtdStr);
            if (quantidade <= 0) {
                JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                return;
            }

            // Verificar estoque disponível
            Estoque estoque = estoqueController.buscarPorProduto(produto);
            if (estoque == null) {
                JOptionPane.showMessageDialog(this, "Produto não possui estoque cadastrado!");
                return;
            }

            // Calcular quantidade já adicionada na venda atual
            int quantidadeJaAdicionada = 0;
            for (ItemVenda item : itensVenda) {
                if (item.getProduto().getId() == produto.getId()) {
                    quantidadeJaAdicionada += item.getQuantidade();
                }
            }

            int quantidadeTotal = quantidadeJaAdicionada + quantidade;
            if (quantidadeTotal > estoque.getQuantidade()) {
                JOptionPane.showMessageDialog(this, 
                    "Estoque insuficiente!\n" +
                    "Disponível: " + estoque.getQuantidade() + "\n" +
                    "Já adicionado: " + quantidadeJaAdicionada + "\n" +
                    "Solicitado: " + quantidade + "\n" +
                    "Total necessário: " + quantidadeTotal);
                return;
            }

            // Verificar se estoque ficará baixo após a venda
            if ((estoque.getQuantidade() - quantidadeTotal) <= estoque.getQuantidadeMinima()) {
                int resposta = JOptionPane.showConfirmDialog(this,
                    "ATENÇÃO: Após esta venda o estoque ficará baixo!\n" +
                    "Estoque atual: " + estoque.getQuantidade() + "\n" +
                    "Após venda: " + (estoque.getQuantidade() - quantidadeTotal) + "\n" +
                    "Mínimo: " + estoque.getQuantidadeMinima() + "\n\n" +
                    "Deseja continuar?",
                    "Alerta de Estoque Baixo",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
                
                if (resposta != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            // Verificar se o produto já existe na venda
            ItemVenda itemExistente = null;
            for (ItemVenda item : itensVenda) {
                if (item.getProduto().getId() == produto.getId()) {
                    itemExistente = item;
                    break;
                }
            }

            if (itemExistente != null) {
                // Produto já existe, atualizar quantidade
                float subtotalAnterior = itemExistente.getSubtotal();
                itemExistente.setQuantidade(itemExistente.getQuantidade() + quantidade);
                itemExistente.calcularSubtotal();
                
                // Atualizar valor total
                valorTotal = valorTotal - subtotalAnterior + itemExistente.getSubtotal();
                
                System.out.println("Produto já existente atualizado: " + produto.getNome() + 
                                 " - Nova quantidade: " + itemExistente.getQuantidade());
            } else {
                // Produto novo, criar item
                ItemVenda novoItem = new ItemVenda();
                novoItem.setProduto(produto);
                novoItem.setQuantidade(quantidade);
                novoItem.setPrecoUnitario(produto.getPreco());
                novoItem.calcularSubtotal();

                itensVenda.add(novoItem);
                valorTotal += novoItem.getSubtotal();
                
                System.out.println("Novo item adicionado: " + produto.getNome() + 
                                 " - Quantidade: " + quantidade);
            }

            txtQuantidade.setText("");
            loadItensVenda();

            // Mostrar estoque restante
            int estoqueRestante = estoque.getQuantidade() - quantidadeTotal;
            System.out.println("Estoque restante de " + produto.getNome() + ": " + estoqueRestante);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantidade deve ser um número válido!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar item: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void removerItem() {
        int selectedRow = tblItens.getSelectedRow();
        if (selectedRow >= 0) {
            ItemVenda item = itensVenda.get(selectedRow);
            
            // Perguntar se quer remover tudo ou apenas uma quantidade
            String[] opcoes = {"Remover Tudo", "Remover Quantidade", "Cancelar"};
            int escolha = JOptionPane.showOptionDialog(this,
                "Como deseja remover o item: " + item.getProduto().getNome() + "?",
                "Remover Item",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]);
            
            if (escolha == 0) { // Remover tudo
                valorTotal -= item.getSubtotal();
                itensVenda.remove(selectedRow);
                System.out.println("Item removido completamente: " + item.getProduto().getNome());
                
            } else if (escolha == 1) { // Remover quantidade específica
                String input = JOptionPane.showInputDialog(this, 
                    "Quantidade atual: " + item.getQuantidade() + "\nQuantidade a remover:",
                    "Remover Quantidade",
                    JOptionPane.QUESTION_MESSAGE);
                
                if (input != null && !input.trim().isEmpty()) {
                    try {
                        int quantidadeRemover = Integer.parseInt(input.trim());
                        if (quantidadeRemover <= 0) {
                            JOptionPane.showMessageDialog(this, "Quantidade deve ser maior que zero!");
                            return;
                        }
                        
                        if (quantidadeRemover >= item.getQuantidade()) {
                            // Remover item inteiro
                            valorTotal -= item.getSubtotal();
                            itensVenda.remove(selectedRow);
                            System.out.println("Item removido completamente: " + item.getProduto().getNome());
                        } else {
                            // Reduzir quantidade
                            float subtotalAnterior = item.getSubtotal();
                            item.setQuantidade(item.getQuantidade() - quantidadeRemover);
                            item.calcularSubtotal();
                            valorTotal = valorTotal - subtotalAnterior + item.getSubtotal();
                            System.out.println("Quantidade reduzida: " + item.getProduto().getNome() + 
                                             " - Nova quantidade: " + item.getQuantidade());
                        }
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Digite um valor numérico válido!");
                        return;
                    }
                }
            }
            // Se escolha == 2 (Cancelar), não faz nada
            
            loadItensVenda();
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um item para remover!");
        }
    }

    private void finalizarVenda() {
        try {
            Cliente cliente = (Cliente) cmbCliente.getSelectedItem();
            if (cliente == null) {
                JOptionPane.showMessageDialog(this, "Selecione um cliente!");
                return;
            }

            if (itensVenda.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Adicione pelo menos um item à venda!");
                return;
            }

            // Validação final de estoque antes de finalizar
            for (ItemVenda item : itensVenda) {
                Estoque estoque = estoqueController.buscarPorProduto(item.getProduto());
                if (estoque == null || estoque.getQuantidade() < item.getQuantidade()) {
                    JOptionPane.showMessageDialog(this, 
                        "Estoque insuficiente para o produto: " + item.getProduto().getNome() + "\n" +
                        "Disponível: " + (estoque != null ? estoque.getQuantidade() : 0) + "\n" +
                        "Necessário: " + item.getQuantidade());
                    return;
                }
            }

            String formaPagamento = (String) cmbFormaPagamento.getSelectedItem();
            
            // Validar forma de pagamento
            if (formaPagamento == null || formaPagamento.equals("Selecione forma de pagamento")) {
                JOptionPane.showMessageDialog(this, "Selecione uma forma de pagamento válida!");
                return;
            }
            
            String observacoes = txtObservacoes.getText().trim();

            Venda venda = new Venda();
            venda.setCliente(cliente);
            venda.setValorTotal(valorTotal);
            venda.setFormaPagamento(formaPagamento);
            venda.setObservacoes(observacoes);

            // Primeiro, associar os itens à venda ANTES de salvar
            for (ItemVenda item : itensVenda) {
                item.setVenda(venda);
            }
            
            // Definir a lista de itens na venda
            venda.setItens(itensVenda);

            System.out.println("=== FINALIZANDO VENDA ===");
            System.out.println("Cliente: " + cliente.getNome());
            System.out.println("Valor Total: R$ " + valorTotal);
            System.out.println("Itens: " + itensVenda.size());

            if (vendaController.salvarVendaCompleta(venda)) {
                System.out.println("Venda salva com ID: " + venda.getId());
                boolean estoqueAtualizado = true;
                
                // Salvar itens da venda individualmente (caso o cascade não funcione)
                for (ItemVenda item : itensVenda) {
                    if (item.getId() == 0) { // Só salva se ainda não foi salvo
                        if (!itemController.salvar(item)) {
                            System.out.println("Erro ao salvar item: " + item.getProduto().getNome());
                        }
                    }
                    
                    // Baixar do estoque apenas para itens extras (não da encomenda)
                    int quantidadeParaBaixar = item.getQuantidade();
                    
                    // Se há encomenda selecionada, descontar a quantidade da encomenda
                    if (encomendaSelecionada != null && itensEncomenda != null) {
                        for (ItemEncomenda itemEnc : itensEncomenda) {
                            if (itemEnc.getProduto().getId() == item.getProduto().getId()) {
                                quantidadeParaBaixar -= itemEnc.getQuantidade();
                                break;
                            }
                        }
                    }
                    
                    // Baixar apenas a quantidade extra do estoque
                    if (quantidadeParaBaixar > 0) {
                        if (!estoqueController.removerEstoque(item.getProduto(), quantidadeParaBaixar)) {
                            estoqueAtualizado = false;
                            System.out.println("Erro ao baixar estoque do produto: " + item.getProduto().getNome());
                        }
                    }
                }

                // Se há encomenda selecionada, marcar como entregue
                if (encomendaSelecionada != null) {
                    if (encomendaController.marcarComoEntregue(encomendaSelecionada)) {
                        System.out.println("Encomenda #" + encomendaSelecionada.getId() + " marcada como entregue");
                    } else {
                        System.out.println("Erro ao marcar encomenda como entregue");
                    }
                }

                String mensagem = "Venda finalizada com sucesso!\nVenda #" + venda.getId();
                if (encomendaSelecionada != null) {
                    mensagem += "\nEncomenda #" + encomendaSelecionada.getId() + " entregue!";
                }
                if (!estoqueAtualizado) {
                    mensagem += "\n\nATENÇÃO: Houve problemas ao atualizar o estoque de alguns produtos.";
                }

                JOptionPane.showMessageDialog(this, mensagem);
                limparVenda();
                loadTabela();
                loadProdutos(); // Recarregar produtos para atualizar disponibilidade
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao finalizar venda!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void limparVenda() {
        itensVenda.clear();
        valorTotal = 0.0f;
        encomendaSelecionada = null;
        itensEncomenda.clear();
        txtQuantidade.setText("");
        txtObservacoes.setText("");
        if (cmbCliente.getItemCount() > 0) cmbCliente.setSelectedIndex(0);
        if (cmbFormaPagamento.getItemCount() > 0) cmbFormaPagamento.setSelectedIndex(0);
        loadItensVenda();
    }

    private void mostrarInfoEstoque() {
        Produto produto = (Produto) cmbProduto.getSelectedItem();
        if (produto != null) {
            Estoque estoque = estoqueController.buscarPorProduto(produto);
            if (estoque != null) {
                String status = estoque.isEstoqueBaixo() ? " (BAIXO)" : " (OK)";
                System.out.println("Produto selecionado: " + produto.getNome() + 
                                 " - Estoque: " + estoque.getQuantidade() + status);
            } else {
                System.out.println("Produto selecionado: " + produto.getNome() + " - SEM ESTOQUE");
            }
        }
    }

    private void gerarCupomFiscal() {
        int selectedRow = tblVendas.getSelectedRow();
        if (selectedRow >= 0) {
            Venda venda = vendas.get(selectedRow);
            
            // Buscar os itens da venda
            List<ItemVenda> itensVenda = itemController.buscarPorVenda(venda.getId());
            venda.setItens(itensVenda);
            
            // Gerar cupom fiscal
            CupomFiscal.gerarCupom(venda);
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma venda na tabela para gerar o cupom fiscal!");
        }
    }



    private void btnSelecionarEncomendaActionPerformed(java.awt.event.ActionEvent evt) {
        selecionarEncomenda();
    }

    private void selecionarEncomenda() {
        Cliente cliente = (Cliente) cmbCliente.getSelectedItem();
        if (cliente == null) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente primeiro!");
            return;
        }

        System.out.println("=== BUSCANDO ENCOMENDAS ===");
        System.out.println("Cliente: " + cliente.getNome() + " (ID: " + cliente.getId() + ")");

        // Buscar encomendas do cliente
        List<Encomenda> encomendasCliente = encomendaController.buscarPorCliente(cliente.getId());
        System.out.println("Encomendas encontradas: " + (encomendasCliente != null ? encomendasCliente.size() : 0));
        
        List<Encomenda> encomendasProntas = new ArrayList<>();
        
        if (encomendasCliente != null) {
            for (Encomenda e : encomendasCliente) {
                System.out.println("Encomenda #" + e.getId() + " - Status: " + e.getStatus());
                if (e.getStatus() == Encomenda.StatusEncomenda.PRONTA) {
                    encomendasProntas.add(e);
                    System.out.println("  -> Adicionada à lista de prontas");
                }
            }
        }

        System.out.println("Encomendas prontas: " + encomendasProntas.size());

        if (encomendasProntas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Este cliente não possui encomendas prontas para retirada!");
            return;
        }

        // Mostrar lista de encomendas para seleção
        Encomenda[] arrayEncomendas = encomendasProntas.toArray(new Encomenda[0]);
        Encomenda encomendaEscolhida = (Encomenda) JOptionPane.showInputDialog(
            this,
            "Selecione a encomenda do cliente:",
            "Encomendas Prontas",
            JOptionPane.QUESTION_MESSAGE,
            null,
            arrayEncomendas,
            arrayEncomendas[0]
        );

        if (encomendaEscolhida != null) {
            adicionarEncomendaAVenda(encomendaEscolhida);
        }
    }

    private void adicionarEncomendaAVenda(Encomenda encomenda) {
        try {
            // Buscar itens da encomenda
            List<ItemEncomenda> itensEncomendaList = itemEncomendaController.buscarPorEncomenda(encomenda.getId());
            
            if (itensEncomendaList == null || itensEncomendaList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Esta encomenda não possui itens!");
                return;
            }

            // Adicionar itens da encomenda à venda
            for (ItemEncomenda itemEncomenda : itensEncomendaList) {
                // Verificar se o produto já existe na venda
                ItemVenda itemExistente = null;
                for (ItemVenda item : itensVenda) {
                    if (item.getProduto().getId() == itemEncomenda.getProduto().getId()) {
                        itemExistente = item;
                        break;
                    }
                }

                if (itemExistente != null) {
                    // Produto já existe, atualizar quantidade
                    float subtotalAnterior = itemExistente.getSubtotal();
                    itemExistente.setQuantidade(itemExistente.getQuantidade() + itemEncomenda.getQuantidade());
                    itemExistente.calcularSubtotal();
                    
                    // Atualizar valor total
                    valorTotal = valorTotal - subtotalAnterior + itemExistente.getSubtotal();
                } else {
                    // Produto novo, criar item
                    ItemVenda novoItem = new ItemVenda();
                    novoItem.setProduto(itemEncomenda.getProduto());
                    novoItem.setQuantidade(itemEncomenda.getQuantidade());
                    novoItem.setPrecoUnitario(itemEncomenda.getPrecoUnitario());
                    novoItem.calcularSubtotal();

                    itensVenda.add(novoItem);
                    valorTotal += novoItem.getSubtotal();
                }
            }

            // Marcar encomenda como selecionada
            encomendaSelecionada = encomenda;
            itensEncomenda = itensEncomendaList;

            // Atualizar interface
            loadItensVenda();
            
            // Adicionar observação sobre a encomenda
            String obsAtual = txtObservacoes.getText().trim();
            String obsEncomenda = "Encomenda #" + encomenda.getId() + " - " + itensEncomendaList.size() + " item(s)";
            if (!obsAtual.isEmpty()) {
                txtObservacoes.setText(obsAtual + " | " + obsEncomenda);
            } else {
                txtObservacoes.setText(obsEncomenda);
            }

            JOptionPane.showMessageDialog(this, 
                "Encomenda #" + encomenda.getId() + " adicionada à venda!\n" +
                "Itens: " + itensEncomendaList.size() + "\n" +
                "Valor: R$ " + String.format("%.2f", encomenda.getValorTotal()));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar encomenda: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmbCliente = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cmbFormaPagamento = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtObservacoes = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cmbProduto = new javax.swing.JComboBox<>();
        cmbProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarInfoEstoque();
            }
        });
        jLabel5 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        btnRemover = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblItens = new javax.swing.JTable();
        lblTotal = new javax.swing.JLabel();
        btnFinalizar = new javax.swing.JButton();
        btnCupomFiscal = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblVendas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Sistema de Vendas - Padaria");
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/icons/Stock Index Up_32x32.png")).getImage());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados da Venda"));

        jLabel1.setText("Cliente:");

        btnSelecionarEncomenda = new javax.swing.JButton();
        btnSelecionarEncomenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Calendar_16x16.png")));
        btnSelecionarEncomenda.setText("Selecionar Encomenda");
        btnSelecionarEncomenda.setBackground(new java.awt.Color(255, 152, 0));
        btnSelecionarEncomenda.setForeground(java.awt.Color.WHITE);
        btnSelecionarEncomenda.setFocusPainted(false);
        btnSelecionarEncomenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelecionarEncomendaActionPerformed(evt);
            }
        });

        jLabel2.setText("Forma Pagamento:");

        jLabel3.setText("Observações:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbCliente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSelecionarEncomenda))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbFormaPagamento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtObservacoes)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cmbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSelecionarEncomenda))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtObservacoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens da Venda"));

        jLabel4.setText("Produto:");

        jLabel5.setText("Quantidade:");

        btnAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Add_16x16.png")));
        btnAdicionar.setText("Adicionar");
        btnAdicionar.setBackground(new java.awt.Color(46, 204, 113));
        btnAdicionar.setForeground(java.awt.Color.WHITE);
        btnAdicionar.setFocusPainted(false);
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        btnRemover.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Remove_16x16.png")));
        btnRemover.setText("Remover");
        btnRemover.setBackground(new java.awt.Color(231, 76, 60));
        btnRemover.setForeground(java.awt.Color.WHITE);
        btnRemover.setFocusPainted(false);
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        tblItens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Quantidade", "Preço Unit.", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblItens);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotal.setText("Total: R$ 0,00");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbProduto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAdicionar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRemover))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblTotal)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cmbProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdicionar)
                    .addComponent(btnRemover))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnFinalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Check_16x16.png")));
        btnFinalizar.setText("Finalizar Venda");
        btnFinalizar.setBackground(new java.awt.Color(39, 174, 96));
        btnFinalizar.setForeground(java.awt.Color.WHITE);
        btnFinalizar.setFocusPainted(false);
        btnFinalizar.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });

        btnCupomFiscal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Print_16x16.png")));
        btnCupomFiscal.setText("Gerar Cupom");
        btnCupomFiscal.setBackground(new java.awt.Color(52, 152, 219));
        btnCupomFiscal.setForeground(java.awt.Color.WHITE);
        btnCupomFiscal.setFocusPainted(false);
        btnCupomFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCupomFiscalActionPerformed(evt);
            }
        });

        btnLimpar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Cancel_16x16.png")));
        btnLimpar.setText("Limpar");
        btnLimpar.setBackground(new java.awt.Color(149, 165, 166));
        btnLimpar.setForeground(java.awt.Color.WHITE);
        btnLimpar.setFocusPainted(false);
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        tblVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Data/Hora", "Cliente", "Valor Total", "Forma Pagamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblVendas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnCupomFiscal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnFinalizar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFinalizar)
                    .addComponent(btnLimpar)
                    .addComponent(btnCupomFiscal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(1000, 700);
        setLocationRelativeTo(null);
    }// </editor-fold>                        

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        adicionarItem();
    }                                            

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {                                           
        removerItem();
    }                                          

    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {                                             
        finalizarVenda();
    }                                            

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {                                          
        limparVenda();
    }                                         

    private void btnCupomFiscalActionPerformed(java.awt.event.ActionEvent evt) {                                               
        gerarCupomFiscal();
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnCupomFiscal;
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnRemover;
    private javax.swing.JButton btnSelecionarEncomenda;
    private javax.swing.JComboBox<Cliente> cmbCliente;
    private javax.swing.JComboBox<String> cmbFormaPagamento;
    private javax.swing.JComboBox<Produto> cmbProduto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblItens;
    private javax.swing.JTable tblVendas;
    private javax.swing.JTextField txtObservacoes;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JLabel lblTotal;
    // End of variables declaration                   
}